# Sharing cover artwork

`school-of-athens.jpg` is a faithful reproduction of Raphael's *The School of Athens* (1509–1511).

- Source: https://commons.wikimedia.org/wiki/File:Raphael_School_of_Athens.jpg
- Original image: https://upload.wikimedia.org/wikipedia/commons/c/c3/Raphael_School_of_Athens.jpg
- Reuse status: public domain, marked PD-Art and PD-old-100-expired by Wikimedia Commons.
- Original dimensions: 3697 × 2414 pixels.
- Original SHA-1: `4848ad7294127045876c11ed5fdbb4924776c90d`.

The sharing cover uses a landscape crop, a subtle dark overlay for contrast, and the site's existing Heavitas font. No generated artwork is used.

Run `python3 scripts/generate-social-preview.py` with Pillow installed to reproduce `public/og.png`.
