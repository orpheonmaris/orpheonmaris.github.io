# Ideology Sorter

A single flowchart quiz containing 201 distinct ideology outcomes, 180 reachable questions and 201 complete routes: one placement for every ideology.

## Editorial rules

- Casing, punctuation, and spelling-only differences are deduplicated.
- Clear equivalents are represented once with transparent aliases, including Bordigism/Programma, Damenism/Battaglia, and Orwellianism/English Socialism.
- Genuine subcurrents remain separate. Examples include the two council-communist organizational models, six communization currents, distinct Maoist lines, and multiple Trotskyist currents.
- Jacobinism and Marxism-Leninism-MZT are the canonical display names; Montagnardism and Dengism remain searchable source aliases.
- Questions are compact and neutral, distinguish positions without naming the result in advance, and make both acceptance and rejection ideologically meaningful.
- Reuse option icons only for genuinely matching meanings. Otherwise create a matching white pictogram; never select icons by broad keywords or answer position. See `AGENTS.md` for the standing icon rules.

The non-state communist/anarchist branch contains 35 questions and 36 results. Its class-struggle branch includes cultural revolt, revolutionary organization, mass federations, autonomous cooperation, and communization; its other branch distinguishes communal life, civilization, and individual revolt. Situationism explicitly combines workers’ council power with transforming everyday life. Endnotes and Chuang have separate results. The final Chuang question asks about its account of Mao-era development, using Yes and No answers.

The Autonomism/Post-Autonomism split concerns the priority given to lasting institutions in the Holloway versus Hardt/Negri debate, rather than a universal division between all autonomist currents. See [their exchange](https://libcom.org/article/creating-commonwealth-and-cracking-capitalism-cross-reading-part-ii-john-holloway-michael) and [Holloway’s interview](https://johnholloway.com.mx/2013/05/01/talking-about-a-revolution-with-john-holloway/).

The Tiqqun/Invisible Committee split asks about strategic priority within closely related projects. Tiqqun emphasizes ties and circulation between distinct forms of life in [This Is Not a Program](https://theanarchistlibrary.org/library/tiqqun-this-is-not-a-program); the Invisible Committee emphasizes communes' material autonomy from infrastructures of power in [To Our Friends](https://theanarchistlibrary.org/library/the-invisible-committe-to-our-friends). Both share these concerns. Material autonomy does not mean isolated self-sufficiency: the latter text explicitly stresses connections beyond each commune.

The Acid Communism/Situationism split concerns parliamentary strategy after the shared class-struggle and cultural-transformation gates. It represents Fisher's political approach and the historical Situationist International, rather than opposing counterculture to council power or defining every contemporary adherent. Fisher's [Acid Communism introduction](https://my-blackout.com/2019/04/25/mark-fisher-acid-communism-unfinished-introduction/) treats Allende's democratic socialism as an emancipatory possibility; his "Not Failing Better, but Fighting to Win" in [K-punk](https://stealthiswiki.com/library/mark-fisher-k-punk-the-collected-and-unpublished-writings) explicitly links movements outside parliament with parliamentary strategy. The Situationists' [May 1968 documents](https://www.bopsecrets.org/SI/May68docs.htm) advocate autonomous workers' councils replacing existing political power. Supporting both cultural liberation and council power therefore no longer forces a choice between the two results.

The U1.61 expansion adds 27 results from the expanded Beingintheera catalogue. The source’s Sison-labelled Marxism-Leninism-Maoism is a searchable alias of the existing Maoism result, while principally Maoism remains separate. The dedicated religion-selector branch and Smiley Fascism remain excluded. New result definitions make priority distinctions explicit, and synthetic entries without an appropriate historical representative use labelled editorial descriptions.

The complete decision graph and ideology metadata live in `app/quiz-data.json`. Route paths are derived at runtime to avoid shipping duplicate data. Static HTML/CSS/JavaScript paints first, then fetches minified quiz data asynchronously. The Tree uses a dense alternating question/arrow grid with two fixed maps, so builds never randomly repack the branches.

Image-heavy indexes and the Tree use generated 360×240 WebP thumbnails. Result pages use generated 960×640 WebP display images instead of loading potentially multi-megabyte source SVGs.

## Local development

Requires Node.js 22.13 or newer.

```sh
npm ci
npm run dev
```

Build and validate:

```sh
npm test
```

Regenerate optimized flag images and the compact public quiz/Tree payloads after changing ideology art or metadata:

```sh
npm run generate:thumbnails
npm run generate:static
```

## License and attribution

This work is distributed under the GNU General Public License v3. See `LICENSE` and the preserved source licenses under `public/source/`.

Selected answer icons use Font Awesome Free 6.7.2 by Fonticons, Inc., licensed under CC BY 4.0. They are adapted with a white fill and square canvas; their original paths are preserved. See `public/assets/icons/README.md` for sources and mappings and `public/source/font-awesome-LICENSE.txt` for the upstream license.

Journal marks used for identification retain their respective rights; they are not newly created or relicensed under the site’s GPL. See `public/assets/unified/flags/JOURNAL-ARTWORK.md` for the official artwork sources.
