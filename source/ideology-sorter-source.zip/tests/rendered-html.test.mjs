import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const data = JSON.parse(fs.readFileSync(path.join(projectRoot, "app/quiz-data.json"), "utf8"));

test("renders the finished site metadata", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const staticHtml = fs.readFileSync(path.join(projectRoot, "public/index.html"), "utf8");
  const response = await worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response(staticHtml, { headers: { "content-type": "text/html; charset=utf-8" } }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );

  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
  const html = await response.text();
  assert.match(html, /<title>Ideology Sorter<\/title>/i);
  assert.match(html, /201 political ideologies through one complete decision tree/i);
  assert.match(html, /width=device-width,initial-scale=1,viewport-fit=cover/i);
  assert.match(html, /href="\/ideosorter\.css\?v=U1\.103"/i);
  assert.match(html, /src="\/ideosorter\.js\?v=U1\.103"/i);
  assert.equal((html.match(/quark88\.github\.io\/ideosorter/gi) || []).length, 1);
  assert.doesNotMatch(html, /beingintheera|Left-WT|Unified IdeoSorter/i);
  assert.ok(fs.existsSync(path.join(projectRoot, "public/source/ideology-sorter-source.zip")));
  assert.ok(!fs.existsSync(path.join(projectRoot, "public/source/unified-ideosorter-source.zip")));
  assert.equal(response.headers.get("cache-control"), "no-cache, max-age=0, must-revalidate");
  assert.doesNotMatch(html, /_next\/static|__next_f|react-server-dom/i);
  assert.doesNotMatch(html, /codex-preview/i);
  assert.ok(fs.statSync(path.join(projectRoot, "dist/server/index.js")).size < 10_000, "static entry worker should not eagerly bundle the app runtime");
});

test("R31 occult-grounding fork separates dated profiles without a biology/spirit dichotomy", () => {
  const node = data.graph.q_raceLarp;
  assert.equal(node.question, "Must racial supremacy rest on occult teachings?");
  assert.deepEqual(node.choices.map(c => [c.label, c.ideology]), [
    ["Yes", "Esoteric Nazism"],
    ["No", "National socialism"],
  ]);
  assert.ok(/distinct mystical or occult doctrine/.test(node.explanation));
  const esoteric = data.ideologies["Esoteric Nazism"];
  assert.ok(esoteric);
  assert.equal(esoteric.author, "Editorial description");
  assert.equal(esoteric.quoteKind, "description");
  assert.ok(esoteric.quote.includes("Savitri Devi and Miguel Serrano"));
  assert.match(esoteric.quote, /did not necessarily reject biological racism/);
  assert.ok(esoteric.quoteSource.citation.includes("Versluis"));
  assert.ok(esoteric.quoteSource.citation.includes("Goodrick-Clarke"));
  assert.deepEqual(esoteric.aliases, []);
  assert.equal(data.ideologies["Esoteric Nazism / Esoteric Fascism"], undefined);
  assert.match(data.ideologies["National socialism"].quote, /not a distinct occult doctrine/);
});

test("R28 people’s-war neighbors have sourced, scoped descriptions and unchanged local answers", () => {
  const yes = data.graph.q_universalPPW.choices.find((choice) => choice.label === "Yes");
  const no = data.graph.q_universalPPW.choices.find((choice) => choice.label === "No");
  assert.equal(yes.ideology, "Marxism-Leninism-Maoism, principally Maoism");
  assert.equal(no.ideology, "Maoism");
  assert.equal(data.graph.q_peopleWar.question, "Should protracted people’s war be the primary revolutionary strategy?");
  for (const result of [yes.ideology, no.ideology]) {
    assert.equal(data.ideologies[result].quoteKind, "description");
    assert.equal(data.ideologies[result].author, "Editorial description");
    assert.ok(data.ideologies[result].quoteSource.url.startsWith("https://"));
    assert.ok(data.ideologies[result].quoteSource.citation);
    assert.ok(data.ideologies[result].quoteSource.note.includes("not"));
  }
  assert.ok(!data.ideologies.Maoism.aliases.includes("Marxism-Leninism-Maoism"),
    "the generic MLM label must not be claimed exclusively by Sison’s specific interpretation");
});


test("R29 Soviet cards clarify their scope while inherited class and agrarian forks remain unchanged", () => {
  const ml = data.ideologies["Marxism-Leninism"];
  const k = data.ideologies["Marxism-Leninism (Khrushchev)"];
  const b = data.ideologies["Developed Socialism (Brezhnev)"];
  for (const c of [ml, k, b]) {
    assert.equal(c.quoteKind, "description");
    assert.equal(c.author, "Editorial description");
    assert.ok(c.quoteSource?.url?.startsWith("https://"));
    assert.ok(c.quoteSource?.citation?.length > 100);
    assert.ok(c.quoteSource?.note?.length > 100);
  }
  assert.match(ml.quote, /Stalin-era Marxism-Leninism/);
  assert.match(ml.quote, /Bukharin/);
  assert.doesNotMatch(ml.quote, /cosmopolitan without a country/);
  assert.match(k.quote, /state of the entire people/);
  assert.match(k.quote, /particular Soviet stage/);
  assert.match(b.quote, /socialist state of the whole people/);
  assert.match(b.quote, /no longer required minimum turnover quotas/);
  assert.equal(data.graph.q_nepTime.question,
    "Was the Soviet Union under Stalin right to forcefully collectivize agriculture?",
    "failed gateway is intentionally unchanged, not certified or silently reworded");
  assert.deepEqual(data.graph.q_nepTime.choices.map(c=>c.label), ["Yes","No"]);
  assert.equal(data.graph.q_nepTime.choices[1].ideology, "Bukharinism");
  assert.equal(data.graph.q_classStruggleSocialism.question,
    "Does class struggle persist within the socialist mode of production?",
    "failed class-struggle gateway is unchanged pending an exclusive evidence-backed repair");
  assert.equal(data.graph.q_khrushBrezhnev.question,
    "Should party rules require a minimum share of new leaders at each election?");
});

test("every merged route terminates in a real ideology with a real flag", () => {
  assert.equal(Object.keys(data.ideologies).length, data.counts.ideologies);
  assert.equal(Object.keys(data.graph).length, data.counts.questions);
  assert.equal("routes" in data, false, "route paths should be derived client-side, not duplicated in the payload");
  assert.ok(data.graph[data.start]);

  const active = new Set();
  const reachedQuestions = new Set();
  const reachedResults = new Set();
  let routeCount = 0;

  function walk(id) {
    assert.ok(!active.has(id), `cycle detected at ${id}`);
    const node = data.graph[id];
    assert.ok(node, `missing question ${id}`);
    assert.ok(node.choices.length >= 2 && node.choices.length <= 6, `invalid choice count at ${id}`);
    active.add(id);
    assert.ok(!reachedQuestions.has(id), `question ${id} has more than one route`);
    reachedQuestions.add(id);
    for (const choice of node.choices) {
      if (choice.type === "question") {
        walk(choice.id);
      } else {
        assert.equal(choice.type, "result", `invalid choice type at ${id}`);
        assert.ok(!reachedResults.has(choice.ideology), `result ${choice.ideology} has more than one route`);
        assert.ok(data.ideologies[choice.ideology], `missing ideology ${choice.ideology}`);
        reachedResults.add(choice.ideology);
        routeCount += 1;
      }
    }
    active.delete(id);
  }

  walk(data.start);
  assert.equal(reachedQuestions.size, data.counts.questions);
  assert.equal(reachedResults.size, data.counts.ideologies);
  assert.equal(routeCount, data.counts.routes);
  assert.equal(routeCount, reachedResults.size, "each ideology should have exactly one best route");

  for (const ideology of Object.values(data.ideologies)) {
    const asset = path.join(projectRoot, "public", ideology.flag.replace(/^\//, ""));
    const thumbnail = path.join(projectRoot, "public", ideology.thumbnail.split("?", 1)[0].replace(/^\//, ""));
    const displayImage = path.join(projectRoot, "public", ideology.image.split("?", 1)[0].replace(/^\//, ""));
    assert.ok(fs.existsSync(asset), `missing flag asset for ${ideology.name}`);
    assert.ok(fs.existsSync(thumbnail), `missing thumbnail for ${ideology.name}`);
    assert.ok(fs.existsSync(displayImage), `missing display image for ${ideology.name}`);
    assert.ok(fs.statSync(thumbnail).size < 25_000, `thumbnail is too large for ${ideology.name}`);
    assert.ok(fs.statSync(displayImage).size < 50_000, `display image is too large for ${ideology.name}`);
    for (const imagePath of [thumbnail, displayImage]) {
      const header = fs.readFileSync(imagePath).subarray(0, 12);
      assert.equal(header.subarray(0, 4).toString(), "RIFF", `invalid WebP header for ${ideology.name}`);
      assert.equal(header.subarray(8, 12).toString(), "WEBP", `invalid WebP signature for ${ideology.name}`);
    }
  }

  // Bound the shipped payload; pretty-printing is not network overhead.
  assert.ok(Buffer.byteLength(JSON.stringify(data)) < 193_000, "quiz payload regressed in size");
});

test("the static payload and Quark-style tree stay compact and complete", () => {
  const publicDataPath = path.join(projectRoot, "public/data/quiz-data.json");
  const treePath = path.join(projectRoot, "public/data/tree-layout.json");
  const html = fs.readFileSync(path.join(projectRoot, "public/index.html"), "utf8");
  const css = fs.readFileSync(path.join(projectRoot, "public/ideosorter.css"), "utf8");
  const client = fs.readFileSync(path.join(projectRoot, "public/ideosorter.js"), "utf8");
  const publicData = JSON.parse(fs.readFileSync(publicDataPath, "utf8"));
  const layouts = JSON.parse(fs.readFileSync(treePath, "utf8"));
  const sourceLayouts = JSON.parse(fs.readFileSync(path.join(projectRoot, "app/tree-layout.json"), "utf8"));
  assert.deepEqual(publicData, data);
  assert.deepEqual(layouts, sourceLayouts, "the public Tree should use the fixed reviewed layout");
  assert.equal(data.version, "U1.103");
  assert.match(html, /\/data\/quiz-data\.json\?v=U1\.103/);
  assert.match(client, /const assetVersion = "U1\.103"/);
  assert.equal(data.graph.q_markets.question, "Should market exchange remain a lasting institution after capitalism?");
  assert.equal(data.graph.q_communism.question, "Should post-capitalist society ultimately be classless, stateless, and moneyless?");
  assert.equal(data.graph.q_feudalRebirth.question, "Should national rebirth favor small private property over large estates and monopolies?");
  assert.match(client, /tree-layout\.json\?v=\$\{assetVersion\}/);
  assert.match(client, /paint-order="stroke fill"/);
  assert.match(client, /dataset\.crossing/);
  assert.match(client, /requestAnimationFrame\(reset\)/, "view changes should reliably reset iOS scroll position");
  assert.match(client, /question\.dataset\.length/, "long questions should receive responsive sizing");
  assert.equal((html.match(/class="ambient-orb ambient-orb-[a-f]"/g) || []).length, 6,
    "the adaptive background should use six lightweight color layers");
  assert.match(css, /\.ambient-background\s*\{/);
  assert.match(css, /radial-gradient\(ellipse at var\(--ambient-x/,
    "ambient colors should span the viewport instead of sitting beyond its edges");
  assert.match(css, /\.ambient-orb-a\s*\{[^}]*--ambient-x:\s*0%/s);
  assert.match(css, /\.ambient-orb-b\s*\{[^}]*--ambient-x:\s*100%/s);
  assert.match(css, /@keyframes ambient-drift/);
  assert.match(css, /transition:\s*color 900ms/);
  assert.match(css, /data-count="2"\] \{ --oa: 0\.48; --ob: 0\.46; \}/,
    "two-answer pages should retain approximately the original blue background's visual strength");
  assert.doesNotMatch(client, /else setAmbientForView\("result"\)/,
    "uncached results should transition directly from the prior palette into the artwork palette");
  assert.match(css, /--accent:\s*#a19d95/);
  assert.doesNotMatch(css, /--blue:|#00a0ff/,
    "the default interface accent should remain neutral rather than blue");
  assert.match(client, /const answerAmbientColors = \[/,
    "question backgrounds should derive from the answer-button palette");
  assert.match(client, /function sampleImagePalette\(image\)/,
    "result backgrounds should derive from the displayed ideology artwork");
  assert.match(client, /context\.drawImage\(image, 0, 0, canvas\.width, canvas\.height\)/,
    "palette sampling should reuse the image already loaded on the result page");
  assert.match(css, /\.arrowCell\[data-crossing\] div/);
  assert.match(css, /min-height:\s*100svh/);
  assert.match(css, /@media \(max-width:\s*680px\)/);
  assert.match(css, /\.question\[data-length="long"\]/);
  assert.match(css, /-webkit-overflow-scrolling:\s*touch/);
  assert.match(css, /\.flag\s*\{[^}]*height:\s*auto;[^}]*object-fit:\s*contain;/s,
    "result artwork should retain its intrinsic proportions without cropping");
  assert.doesNotMatch(css, /\.flag\s*\{[^}]*object-fit:\s*cover;/s,
    "mobile result artwork should never be cropped");
  assert.doesNotMatch(css, /data-stack/);

  assert.equal((html.match(/class="tree-scroll"/g) || []).length, 2, "each tree needs its own scrolling canvas");
  assert.match(css, /--tree-node-width:\s*8\.625rem/);
  assert.match(css, /--tree-node-height:\s*5\.75rem/);
  assert.match(css, /--tree-arrow-size:\s*3\.75rem/);
  assert.match(client, /var\(--tree-node-width\) var\(--tree-arrow-size\)/);
  assert.match(client, /var\(--tree-node-height\) var\(--tree-arrow-size\)/);
  assert.doesNotMatch(client, /element\.style\.aspectRatio/, "the merged tree must scroll instead of being squeezed to the viewport");

  const coreFiles = ["index.html", "ideosorter.css", "ideosorter.js"]
    .map((name) => path.join(projectRoot, "public", name));
  const initialAndTreeBytes = [...coreFiles, publicDataPath, treePath]
    .reduce((sum, file) => sum + fs.statSync(file).size, 0);
  // R32 adds one question and three source-backed descriptions; allow 323 KB uncompressed core.
  // This measures HTML, CSS, JS, quiz JSON, and tree JSON together.
  assert.ok(initialAndTreeBytes < 323_000, `static core regressed to ${initialAndTreeBytes} bytes`);

  const coveredQuestions = new Set();
  const coveredResults = new Set();
  for (const [branch, rootId] of [["pro", "q_constitution"], ["anti", "q_markets"]]) {
    const layout = layouts[branch];
    const byKey = new Map(layout.cells.map((cell) => [cell.key, cell]));
    assert.equal(byKey.size, layout.cells.length, `${branch} tree repeats a question or result`);
    const coordinates = new Set();
    for (const cell of layout.cells) {
      const coordinate = `${cell.column}:${cell.row}`;
      assert.ok(!coordinates.has(coordinate), `duplicate ${branch} tree cell at ${coordinate}`);
      coordinates.add(coordinate);
      if (cell.type === "question") {
        assert.ok(data.graph[cell.id], `orphan ${branch} question cell ${cell.id}`);
        assert.ok(!coveredQuestions.has(cell.id), `question ${cell.id} appears in both tree maps`);
        coveredQuestions.add(cell.id);
      } else {
        assert.equal(cell.type, "result");
        assert.ok(data.ideologies[cell.ideology], `orphan ${branch} result cell ${cell.ideology}`);
        assert.ok(!coveredResults.has(cell.ideology), `result ${cell.ideology} appears in both tree maps`);
        coveredResults.add(cell.ideology);
      }
    }
    assert.equal(byKey.get(`question:${rootId}`).start, true);
    for (const cell of layout.cells.filter((item) => item.type === "question")) {
      for (const choice of data.graph[cell.id].choices) {
        const targetKey = choice.type === "question" ? `question:${choice.id}` : `result:${choice.ideology}`;
        const target = byKey.get(targetKey);
        assert.ok(target, `missing ${branch} tree target ${targetKey}`);
        const dx = Math.abs(target.column - cell.column);
        const dy = Math.abs(target.row - cell.row);
        assert.ok(dx <= 1 && dy <= 1 && dx + dy > 0, `non-adjacent tree edge ${cell.key} -> ${targetKey}`);
      }
    }

    const maximum = branch === "pro" ? { width: 14, height: 16, crossings: 11 } : { width: 14, height: 18, crossings: 16 };
    assert.ok(layout.width <= maximum.width, `${branch} tree is wider than its Quark-style row layout`);
    assert.ok(layout.height <= maximum.height, `${branch} tree is taller than its Quark-style row layout`);
    const minimumDensity = branch === "pro" ? 0.79 : 0.80;
    assert.ok(layout.cells.length / (layout.width * layout.height) >= minimumDensity, `${branch} tree row packing is too sparse`);

    const diagonalGaps = new Set();
    let crossings = 0;
    for (const cell of layout.cells.filter((item) => item.type === "question")) {
      for (const choice of data.graph[cell.id].choices) {
        const targetKey = choice.type === "question" ? `question:${choice.id}` : `result:${choice.ideology}`;
        const target = byKey.get(targetKey);
        const dx = target.column - cell.column;
        const dy = target.row - cell.row;
        if (Math.abs(dx) === 1 && Math.abs(dy) === 1) {
          const gap = `${cell.column * 2 + dx}:${cell.row * 2 + dy}`;
          if (diagonalGaps.has(gap)) crossings += 1;
          diagonalGaps.add(gap);
        }
      }
    }
    assert.equal(crossings, layout.crossings, `${branch} crossing metadata is stale`);
    assert.ok(crossings <= maximum.crossings, `${branch} tree has too many diagonal crossings`);
  }
  assert.equal(coveredQuestions.size, data.counts.questions - 1, "branch maps should include every question after the initial property split");
  assert.equal(coveredResults.size, data.counts.ideologies);

  const proByKey = new Map(layouts.pro.cells.map((cell) => [cell.key, cell]));
  const antiByKey = new Map(layouts.anti.cells.map((cell) => [cell.key, cell]));
  const assertDirection = (byKey, parentKey, childKey, dx, dy) => {
    const parent = byKey.get(parentKey);
    const child = byKey.get(childKey);
    assert.deepEqual([child.column - parent.column, child.row - parent.row], [dx, dy]);
  };
  assertDirection(proByKey, "question:q_constitution", "question:q_stateFunctions", -1, -1);
  assertDirection(proByKey, "question:q_constitution", "question:q_minarchy", 1, 0);
  assertDirection(proByKey, "question:q_constitution", "question:q_voluntaryMonarch", -1, 1);
  assertDirection(antiByKey, "question:q_markets", "question:q_authMarkSoc", 1, -1);
  assertDirection(antiByKey, "question:q_markets", "question:q_communism", -1, 1);
});

test("every answer has an explicitly assigned icon and both renderers agree", () => {
  function loadIconResolver(relativePath) {
    const source = fs.readFileSync(path.join(projectRoot, relativePath), "utf8");
    const sets = source.match(/const (?:quark|left)IconLabels = new Set\(\[[\s\S]*?\]\);/g);
    const overrides = source.match(/const answerIconOverrides[^=]*= \{[\s\S]*?\n\s*\};/)[0]
      .replace(": Record<string, string>", "");
    const resolver = source.match(/function answerIcon\([^)]*\) \{[\s\S]*?\n\s*\}/)[0]
      .replaceAll(": string", "");
    assert.doesNotMatch(resolver, /key\.includes\(/, "broad keyword guesses must not select icons");
    return vm.runInNewContext([...sets, overrides, resolver, "answerIcon"].join("\n"));
  }

  const staticIcon = loadIconResolver("public/ideosorter.js");
  const reactIcon = loadIconResolver("app/page.tsx");
  for (const [nodeId, node] of Object.entries(data.graph)) {
    for (const { label } of node.choices) {
      const icon = staticIcon(nodeId, label);
      assert.doesNotMatch(icon, /missing\.svg$/, `assign a reviewed icon to ${nodeId}: ${label}`);
      assert.equal(icon, reactIcon(nodeId, label), `renderer mismatch at ${nodeId}: ${label}`);
      assert.ok(fs.existsSync(path.join(projectRoot, "public", icon)), `missing icon asset ${icon}`);
    }
  }

  for (const [label, expectedIcon] of [
    ["Yes", "/assets/quark/buttons/yes.svg"],
    ["No", "/assets/quark/buttons/no.svg"],
  ]) {
    assert.equal(staticIcon("q_nsChuang", label), expectedIcon);
  }
  assert.match(staticIcon("unreviewed", "A revolutionary council organization"), /missing\.svg$/,
    "new wording needs a deliberate semantic assignment, not a keyword guess");
});

test("the entire dedicated religious branch is removed without cutting other political routes", () => {
  const removedQuestions = ["q_religion", "q_whatreligion", "q_anarchochrist", "q_anarchoislam", "q_anarchojewish", "q_anarchoconfucian"];
  const removedIdeologies = ["Christian Anarchism", "Liberation Theology", "Islamic Anarcho-Communism", "Islamic Socialism", "Jewish Anarcho-Communism", "Labour Zionism", "Confucian Anarcho-Communism", "Confucian Socialism"];
  for (const id of removedQuestions) assert.ok(!(id in data.graph), `removed religious question returned: ${id}`);
  for (const name of removedIdeologies) assert.ok(!(name in data.ideologies), `removed religious outcome returned: ${name}`);
  assert.deepEqual(data.graph.q_communism.choices, [
    { label: "Yes", type: "question", id: "q_dotp" },
    { label: "No", type: "question", id: "q_weed" },
  ]);
  assert.equal(data.counts.ideologies, 201);
  assert.equal(data.counts.questions, 183);
  assert.equal(data.counts.routes, 201);
  assert.equal(data.counts.leftOnly, 43);
  assert.equal(data.counts.curated, 34);
  assert.equal(Object.values(data.ideologies).filter(i => i.source === "curated").length, data.counts.curated);
  assert.equal(Object.values(data.ideologies).filter(i => i.source === "left").length, data.counts.leftOnly);
  assert.ok(data.ideologies["Clerical Fascism"], "unrelated political branches should remain intact");
  assert.ok(data.graph.q_fumivFascfu, "religion-related distinctions outside the removed section should remain intact");
  const tree = JSON.parse(fs.readFileSync(path.join(projectRoot, "public/data/tree-layout.json"), "utf8"));
  for (const branch of Object.values(tree)) {
    for (const cell of branch.cells) {
      assert.ok(!removedQuestions.includes(cell.id));
      assert.ok(!removedIdeologies.includes(cell.ideology));
    }
  }
});

test("the redesigned non-state branch preserves every result and the approved political routes", () => {
  const root = data.graph.q_dotp.choices.find((choice) => choice.label === "No").id;
  assert.equal(root, "q_nsClassStruggle");
  const questions = new Set();
  const routes = new Map();
  function collect(id, route = []) {
    assert.ok(!questions.has(id), `non-state question ${id} has multiple parents`);
    questions.add(id);
    for (const choice of data.graph[id].choices) {
      const nextRoute = [...route, [id, choice.label]];
      if (choice.type === "question") collect(choice.id, nextRoute);
      else {
        assert.ok(!routes.has(choice.ideology), `non-state outcome ${choice.ideology} has multiple routes`);
        routes.set(choice.ideology, nextRoute);
      }
    }
  }
  collect(root);
  assert.equal(questions.size, 35);
  assert.equal(routes.size, 36);
  assert.deepEqual([...questions].sort(), Object.keys(data.graph).filter((id) => id.startsWith("q_ns")).sort(),
    "every redesigned question should belong to the No-workers-state branch");

  const retainedResults = [
    "Anarchism Without Adjectives", "Anarcho-Nihilism", "Anarcho-collectivism", "Anarcho-communism",
    "Anarcho-primitivism", "Anarcho-syndicalism", "Autonomism", "Camattism",
    "Communization (Théorie Communiste)", "Communization (Tiqqun)", "Communization (Troploin)",
    "Democratic Confederalism", "Ego-Communism", "Especifismo", "Illegalism",
    "Immortalism (Palingenetic)", "Immortalist Communism", "Individualist Anarchism",
    "Insurrectionary Anarchism", "Libertarian Marxism", "Libertarian municipalism", "Mao-Spontex",
    "Platformism", "Post-Autonomism", "Situationism", "Sorelianism", "Synthesis Anarchism",
  ];
  const addedResults = [
    "Acéphaleism", "Acid Communism", "Anti-Civilization", "Communization (Chuang)",
    "Communization (Endnotes)", "Communization (The Invisible Committee)",
    "Post-Civilization", "Post-Left Anarchism", "Surrealism",
  ];
  assert.deepEqual([...routes.keys()].sort(), [...retainedResults, ...addedResults].sort(),
    "all 27 original results and all 9 additions should have their own endpoint");
  assert.equal([...routes.values()].filter((route) => route[0][1] === "Yes").length, 22);
  assert.equal([...routes.values()].filter((route) => route[0][1] === "No").length, 14);

  const removedQuestions = [
    "q_agriculture", "q_anarchistTendencies", "q_anarchoUnions", "q_anarchosyn", "q_areasofstruggle",
    "q_bookchin", "q_commAnarchySplit", "q_communization", "q_communizationParty", "q_demconf",
    "q_egoCom", "q_illegalism", "q_immortalParty", "q_insurrection", "q_maospontex",
    "q_massMvmtRoot", "q_multitude", "q_myth", "q_nature", "q_nihlism", "q_platform",
    "q_situationism", "q_tiqqunForms", "q_vouchers", "q_workerscouncils",
  ];
  for (const id of removedQuestions) assert.equal(data.graph[id], undefined, `obsolete question ${id} returned`);

  assert.deepEqual(routes.get("Situationism"), [
    ["q_nsClassStruggle", "Yes"],
    ["q_nsCulture", "Yes"],
    ["q_nsDreams", "No"],
    ["q_nsCulturalRevolt", "No"],
  ], "Situationism should combine everyday cultural transformation with rejection of parliamentary strategy, without requiring rejection of proletarian dictatorship");

  const partyRoute = [
    ["q_nsClassStruggle", "Yes"], ["q_nsCulture", "No"], ["q_nsLeadership", "Yes"], ["q_nsParty", "Yes"],
  ];
  assert.deepEqual(routes.get("Mao-Spontex"), [...partyRoute, ["q_nsCulturalRevolution", "Yes"]]);
  assert.deepEqual(routes.get("Immortalism (Palingenetic)"), [
    ...partyRoute, ["q_nsCulturalRevolution", "No"], ["q_nsWorldwideParty", "Through a single, globally integrated communist party."],
  ]);
  assert.deepEqual(routes.get("Immortalist Communism"), [
    ...partyRoute, ["q_nsCulturalRevolution", "No"], ["q_nsWorldwideParty", "Across multiple interacting communist organizations."],
  ]);
  assert.equal(data.graph.q_nsWorldwideParty.question,
    "How should communist revolutionary leadership be organized?");

  const civilizationRoute = [["q_nsClassStruggle", "No"], ["q_nsCivilization", "Yes"]];
  assert.deepEqual(routes.get("Camattism"), [
    ...civilizationRoute, ["q_nsCivilizationRevolution", "No"],
  ], "Camattism should follow the civilization critique, without requiring rejection of communal life or ritual");
  assert.deepEqual(routes.get("Anarcho-primitivism"), [
    ...civilizationRoute, ["q_nsCivilizationRevolution", "Yes"], ["q_nsPreAgricultural", "Yes"],
  ]);
  const communalRoute = [
    ["q_nsClassStruggle", "No"], ["q_nsCivilization", "No"],
    ["q_nsCommunalLife", "Yes"], ["q_nsPublicAssemblies", "No"],
  ];
  assert.deepEqual(routes.get("Acéphaleism"), [
    ...communalRoute, ["q_nsCommunalInsurrection", "Shared ritual and ecstasy"],
  ]);
  for (const ideology of ["Communization (Tiqqun)", "Communization (The Invisible Committee)"]) {
    assert.deepEqual(routes.get(ideology).slice(0, -1), [
      ...communalRoute, ["q_nsCommunalInsurrection", "Common insurrectionary struggle"],
    ]);
  }
  assert.equal(data.graph.q_nsRitual, undefined, "the obsolete Camattism ritual fork should be removed");

  const communizationRoute = [
    ["q_nsClassStruggle", "Yes"], ["q_nsCulture", "No"], ["q_nsLeadership", "No"],
    ["q_nsMassOrganizations", "No"], ["q_nsInsurrection", "No"], ["q_nsAutonomousCooperation", "No"],
  ];
  assert.deepEqual(routes.get("Communization (Troploin)"), [
    ...communizationRoute, ["q_nsEarlierRevolutions", "Yes"],
  ]);
  assert.deepEqual(routes.get("Communization (Théorie Communiste)"), [
    ...communizationRoute, ["q_nsEarlierRevolutions", "No"], ["q_nsSubsumption", "Yes"],
  ]);
  const finalForkRoute = [...communizationRoute, ["q_nsEarlierRevolutions", "No"], ["q_nsSubsumption", "No"]];
  assert.deepEqual(routes.get("Communization (Chuang)"), [
    ...finalForkRoute, ["q_nsChuang", "Yes"],
  ]);
  assert.deepEqual(routes.get("Communization (Endnotes)"), [
    ...finalForkRoute, ["q_nsChuang", "No"],
  ]);
  assert.equal(data.graph.q_nsChuang.question,
    "Did Mao-era China interrupt capitalism without creating a coherent new economy?");
  assert.equal(data.graph.q_nsChuang.help, undefined);
  assert.equal(data.graph.q_nsSubsumption.help, undefined);
  assert.ok(!(data.ideologies["Communization (Théorie Communiste)"].aliases ?? []).some((alias) => /endnotes/i.test(alias)),
    "Endnotes should be its own result rather than an alias of Théorie Communiste");
});

test("requested canonical names and placements are preserved", () => {
  const targets = (id) => data.graph[id].choices.map((choice) => choice.type === "question" ? choice.id : choice.ideology);

  assert.ok(data.ideologies.Jacobinism);
  assert.ok(data.ideologies.Jacobinism.aliases.includes("Montagnardism"));
  assert.equal(data.ideologies.Montagnardism, undefined);
  assert.equal(data.graph.q_castes, undefined);
  assert.equal(data.graph.q_jacobinEmergency, undefined);
  assert.equal(data.graph.q_stateFunctions.question, "Who should exercise the state's governing authority?");
  assert.deepEqual(targets("q_stateFunctions"), ["q_futarchy", "q_pragmaticStrongman", "q_proOrganic"]);
  assert.equal(data.graph.q_plebiscitaryRule, undefined, "the early plebiscite question should be removed");
  assert.deepEqual(targets("q_pragmaticStrongman"), ["q_racism", "q_strongmanLegit"]);
  assert.deepEqual(data.graph.q_strongmanLegit.choices, [
    { label: "Direct popular mandate", type: "result", ideology: "Bonapartism" },
    { label: "Charisma", type: "result", ideology: "Personal autocracy" },
    { label: "Armed forces", type: "result", ideology: "Stratocracy" },
    { label: "Connections", type: "result", ideology: "Patronalism" },
  ]);
  assert.equal(data.graph.q_organizedInterests.question, "Should independent trade unions have a political role?");
  assert.deepEqual(targets("q_organizedInterests"), ["q_socCorp", "Jacobinism"]);
  assert.equal(data.graph.q_palingenesis.choices[1].id, "q_control");

  assert.ok(data.ideologies["Marxism-Leninism-MZT"]);
  assert.ok(data.ideologies["Marxism-Leninism-MZT"].aliases.includes("Dengism"));
  assert.equal(data.ideologies.Dengism, undefined);

  assert.equal(data.graph.q_ethnic.choices[1].id, "q_mutual");
  assert.equal(data.graph.q_proudhon.question, "Must large industries be organized as workers’ associations?");
  assert.deepEqual(targets("q_proudhon"), ["Proudhonian Mutualism", "Tuckerite Mutualism"]);
  assert.equal(data.graph.q_mutualistCurrent, undefined);
  assert.equal(data.ideologies["Tuckerite Mutualism"].flag, "/assets/left/flags/Tuckerite Mutualism.svg");
  assert.match(data.ideologies["Tuckerite Mutualism"].thumbnail, /\?v=U1\.3$/);

  assert.equal(data.ideologies["Classical social democracy"], undefined);
  assert.equal(data.ideologies["Marxism-leninism-maoism"], undefined);

  assert.equal(data.graph.q_dotp.question, "Should the transitional period take on a state-form?");
  assert.equal(data.graph.q_dotp.choices[0].id, "q_foco");
  assert.equal(data.graph.q_dotp.choices[1].id, "q_nsClassStruggle");
  assert.equal(data.graph.q_stalinCope.question, "Can commodity production exist under the socialist mode of production?");
  assert.deepEqual(targets("q_stalinCope"), ["q_pluralistAlliance", "q_reform"]);
  assert.deepEqual(targets("q_nepTime"), ["q_classStruggleSocialism", "Bukharinism"]);
  assert.deepEqual(targets("q_chinaBourgeois"), ["Anti-Revisionist Marxism-Leninism", "q_laborAristocracy"]);
  assert.deepEqual(targets("q_peopleWar"), ["q_universalPPW", "q_natCom"]);
  assert.deepEqual(targets("q_universalPPW"), ["Marxism-Leninism-Maoism, principally Maoism", "Maoism"]);
  assert.deepEqual(targets("q_laborAristocracy"), ["Maoism-Third-Worldism", "q_peopleWar"]);
  assert.equal(data.graph.q_muhCapitalistRoaders, undefined);
  assert.equal(data.graph.q_marketPolitical, undefined);
  assert.deepEqual(targets("q_socialistMarkets"), ["q_enterprisePlans", "q_nepTime"]);
  assert.deepEqual(targets("q_enterprisePlans"), ["Titoism", "Marxism-Leninism-MZT"]);
  assert.deepEqual(targets("q_natCom"), ["q_songun", "Marxism-Leninism"]);
  assert.deepEqual(targets("q_songun"), ["Juche", "National Communism"]);
  assert.deepEqual(targets("q_khrushBrezhnev"), ["Marxism-Leninism (Khrushchev)", "Developed Socialism (Brezhnev)"]);

  assert.equal(data.graph.q_demCent.choices[0].id, "q_proletarianculture");
  assert.equal(data.graph.q_demCent.choices[1].id, "q_councilNationalWar");
  assert.equal(data.graph.q_immediateAbolition, undefined);
  assert.equal(data.graph.q_proletarianculture.choices[0].id, "q_scientificCulture");
  assert.equal(data.graph.q_proletarianculture.choices[1].id, "q_unionAdministration");
  assert.deepEqual(targets("q_leninism"), ["Left Marxism-Leninism", "q_natLib"]);
  assert.equal(data.graph.q_natLib.choices[0].id, "q_peasantPower");
  assert.equal(data.graph.q_natLib.choices[1].id, "q_organic");
  assert.equal(data.graph.q_organic.question, "Should the communist party itself exercise the dictatorship of the proletariat?");
  assert.deepEqual(targets("q_organic"), ["Italian Left-Communism (Programma)", "q_parliamentaryAgitation"]);
  assert.deepEqual(targets("q_parliamentaryAgitation"), ["Spartacism (Luxemburgism)", "Italian Left-Communism (Battaglia)"]);
  assert.equal(data.graph.q_peasantPower.choices[0].ideology, "Leninism");
  assert.equal(data.graph.q_peasantPower.choices[1].id, "q_dws");
  assert.deepEqual(targets("q_dws"), ["q_trotskyCurrent", "q_bureaucraticCollectivism"]);
  assert.deepEqual(targets("q_trotskyCurrent"), ["Posadism", "Orthodox Trotskyism"]);

  assert.equal(data.graph.q_reform.choices[0].id, "q_massparty");
  assert.equal(data.graph.q_reform.choices[1].id, "q_demCent");
  assert.equal(data.graph.q_massparty.choices[0].id, "q_deLeon");
  assert.equal(data.graph.q_massparty.choices[1].ideology, "Classical Marxism");
  assert.equal(data.graph.q_deLeon.choices[0].ideology, "De Leonism");
  assert.equal(data.graph.q_deLeon.choices[1].ideology, "Orthodox Marxism");
  assert.equal(data.graph.q_electoralism, undefined);
  assert.equal(data.graph.q_partyElites.question, "Should a distinct political organization act alongside the workers’ councils?");
  assert.deepEqual(targets("q_partyElites"), ["Council Communism (Organizational Dualism)", "Council Communism (Organizational Unitarism)"]);
  for (const name of ["Camattism", "Communization (Théorie Communiste)", "Communization (Tiqqun)", "Communization (Troploin)"]) {
    assert.match(data.ideologies[name].flag, /\/assets\/unified\/flags\/communization-/);
    assert.ok(data.ideologies[name].quote.length > 30);
  }

  assert.equal(data.ideologies["Classical Marxism"].source, "curated");
  assert.equal(data.ideologies["Orthodox Marxism"].source, "curated");
  assert.equal(data.ideologies.Leninism.source, "curated");
  assert.equal(data.ideologies["Immortalist Communism"].source, "curated");
  assert.equal(data.ideologies["Immortalist Communism"].quote, "By tracing out the limits of any given struggle, these participants find themselves elaborating a larger pattern, principle, or truth: the invariant idea of communism.");
  assert.equal(data.ideologies["Immortalism (Palingenetic)"].source, "curated");
  assert.equal(data.ideologies["Immortalism (Palingenetic)"].author, "Ari Antheus");
  assert.equal(data.ideologies["Immortalism (Palingenetic)"].quote, "Communism is not an ideal to be realized or a doctrine to be constructed; it is the real movement immanent to capital, the invariant tendency produced by the contradictions latent in the mode of production.");
  assert.ok(data.ideologies["Immortalism (Palingenetic)"].aliases.includes("Post-Hegelian Palingenetic Communism"));
  assert.ok(data.ideologies["Immortalism (Palingenetic)"].aliases.includes("Palingenetic Communism"));
  assert.equal(data.ideologies["Palingenetic Communism"], undefined);
  assert.equal(data.ideologies["Communization (Troploin)"].author, "Gilles Dauvé & Karl Nesic");
  assert.equal(data.ideologies["Communization (Troploin)"].quote, "Communism is not a new “economy”, even a regulated, bottom-up, decentralized and self-managed one.");
  assert.equal(data.ideologies["Communization (Théorie Communiste)"].author, "Théorie Communiste");
  assert.equal(data.ideologies["Communization (Théorie Communiste)"].quote, "Revolution is communisation; it does not have communism as a project and result, but as its very content.");
});

test("the approved catalogue expansion preserves existing results and distinguishes new routes", () => {
  const previous = JSON.parse(fs.readFileSync(path.join(projectRoot, "tests/fixtures/pre-u1-61-results.json"), "utf8"));
  const additions = [
    "Anarcho-Monarchism", "Bismarckism", "Bonapartism", "Communist Futurism",
    "Conservative Liberalism", "Distributist Reactionaryism", "Eurocommunism",
    "Falangism (De Jons)", "Focoism", "Futarchy", "Gastevism", "Landian Accelerationism",
    "Legionarism", "Megacorporatocracy", "National Bolshevism (Laufenberg)",
    "National Bolshevism (NBF)", "National Bolshevism (Paetel)", "Neosocialism",
    "Objectivism", "Reactionary Esotericism", "Reactionaryism", "Religious Corporatism",
    "Schmittianism", "Shachtmanism", "Social Credit", "Voluntaryism", "Workers’ Oppositionism",
  ];
  assert.equal(previous.length, 174);
  const scopedNames = { "Esoteric Nazism / Esoteric Fascism": "Esoteric Nazism", "Developed Socialism": "Developed Socialism (Brezhnev)", "Fordism": "World State (Brave New World)", "Orwellianism / English Socialism": "Ingsoc", "Market anarchism": "Market anarchism (Carson)", "National anarchism": "National anarchism (Southgate, 2009)" };
  assert.deepEqual(Object.keys(data.ideologies).sort(), [...previous, ...additions].map((name) => scopedNames[name] ?? name).sort());
  for (const name of additions) {
    assert.ok(data.ideologies[name].description.length > 30, `missing definition for ${name}`);
    assert.ok(data.ideologies[name].flag.startsWith("/assets/expanded/flags/"));
  }
  assert.ok(data.ideologies.Maoism.aliases.includes("Marxism-Leninism-Maoism (Sison)"));
  assert.equal(data.ideologies["Marxism-Leninism-Maoism"], undefined);
  assert.equal(data.ideologies["Smiley Fascism"], undefined);
  assert.equal(data.ideologies["Smiley Facism"], undefined);

  const routes = new Map();
  function walk(id, trail = []) {
    for (const c of data.graph[id].choices) {
      const next = [...trail, [id, c.label]];
      if (c.type === "question") walk(c.id, next);
      else routes.set(c.ideology, next);
    }
  }
  walk(data.start);
  for (const name of ["Eurocommunism", "Focoism"]) {
    const route = routes.get(name);
    assert.ok(route.some(([id, answer]) => id === "q_dotp" && answer === "Yes"));
    assert.ok(!route.some(([id]) => id === "q_demCent"), `${name} inherited an incompatible preliminary gate`);
    if (name === "Focoism") assert.ok(!route.some(([id]) => id === "q_stalinCope"), "Focoism must not inherit an economic doctrine");
  }
  assert.deepEqual(routes.get("Eurocommunism").slice(-2), [["q_stalinCope", "Yes"], ["q_pluralistAlliance", "Yes"]]);
  assert.deepEqual(routes.get("Focoism").slice(-2), [["q_dotp", "Yes"], ["q_foco", "Yes"]]);
  assert.deepEqual(routes.get("National Bolshevism (Laufenberg)").slice(-2), [["q_demCent", "No"], ["q_councilNationalWar", "Yes"]]);
  assert.ok(routes.get("National Bolshevism (NBF)").some(([id, answer]) => id === "q_dugin" && answer === "Yes"));
  assert.ok(routes.get("Legionarism").some(([id, answer]) => id === "q_racism" && answer === "Yes"));
  assert.equal(data.graph.q_sovereignType.choices.length, 6);
  assert.equal(data.graph.q_sovereignType.choices[5].ideology, "Schmittianism");
  for (const name of ["Megacorporatocracy", "Distributist Reactionaryism"]) {
    assert.equal(data.ideologies[name].quoteKind, "description");
    assert.equal(data.ideologies[name].author, "Editorial description");
  }
  const client = fs.readFileSync(path.join(projectRoot, "public/ideosorter.js"), "utf8");
  const react = fs.readFileSync(path.join(projectRoot, "app/page.tsx"), "utf8");
  assert.match(client, /quoteKind === "description"/);
  assert.match(react, /quoteKind === "description"/);
  assert.match(client, /result-description/);
});

test("catalogue additions preserve the previously approved question wording", () => {
  const wording = JSON.parse(fs.readFileSync(path.join(projectRoot, "tests/fixtures/pre-expansion-question-wording.json"), "utf8"));
  const revisions = Object.assign({}, ...["e1-r2-wording-revisions.json", "e1-r3-wording-revisions.json", "e1-r9-wording-revisions.json", "e1-r10-wording-revisions.json", "e1-r12-wording-revisions.json", "e1-r14-wording-revisions.json", "e1-r23-wording-revisions.json", "e1-r25-wording-revisions.json", "e1-r26-wording-revisions.json", "e1-r31-wording-revisions.json", "e1-r32-wording-revisions.json"].map((name) => JSON.parse(fs.readFileSync(path.join(projectRoot, "tests/fixtures", name), "utf8"))));
  for (const [id, question] of Object.entries(wording)) {
    if (id === "q_muhCapitalistRoaders") {
      assert.equal(question, "Did the post-Mao reforms restore capitalism in China?");
      assert.equal(data.graph[id], undefined, "R21 retires the old Deng junction");
      continue;
    }
    if (revisions[id]) assert.equal(revisions[id].before, question, `revision baseline changed at ${id}`);
    assert.equal(data.graph[id]?.question, revisions[id]?.after ?? question, `previous question wording changed at ${id}`);
  }
  assert.deepEqual(data.graph.q_counterEcon.choices, [
    { label: "Withdrawal of cooperation", type: "question", id: "q_withdrawalStrategy" },
    { label: "Insurrection", type: "question", id: "q_anDist" },
  ]);
});

test("R9 source-backed local profiles reach their scoped results without claiming ancestor validity", () => {
  const review = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/coordination-repair-R9.json"), "utf8"));
  const sourceIds = new Set(review.sources.map((source) => source.id));
  assert.equal(review.profiles.length, 4);
  for (const profile of review.profiles) {
    assert.equal(profile.independent_complete_answers, null);
    let questionId = profile.local_start;
    let result;
    for (const step of profile.local_answers) {
      assert.equal(questionId, step.question_id, `unexpected local question for ${profile.subject}`);
      assert.ok(sourceIds.has(step.source) && step.reference, `missing independent evidence for ${profile.subject}`);
      const choice = data.graph[questionId].choices.find((item) => item.label === step.answer);
      assert.ok(choice, `missing documented answer for ${profile.subject}`);
      if (choice.type === "question") questionId = choice.id;
      else { result = choice.ideology; questionId = undefined; }
    }
    assert.equal(result, profile.expected_result);
  }
  assert.ok(review.ancestor_findings.some((finding) => finding.question_id === "q_privateProperty"));
  assert.ok(review.ancestor_findings.some((finding) => finding.question_id === "q_stateFunctions"));
});

test("player-facing counts and useful aliases match the current decision tree", () => {
  const source = fs.readFileSync(path.join(projectRoot, "public/ideosorter.js"), "utf8");
  const helperSource = source.slice(source.indexOf("  function countOutcomes("), source.indexOf("  const outcomeCounts = new Map();"));
  const helpers = vm.runInNewContext(`${helperSource}\n({ countOutcomes, countLabel, displayAliases })`);
  const reachable = (id) => data.graph[id].choices.flatMap((choice) => choice.type === "result" ? [choice.ideology] : reachable(choice.id));
  for (const id of Object.keys(data.graph)) {
    assert.equal(helpers.countOutcomes(data.graph, id), new Set(reachable(id)).size, `wrong remaining count at ${id}`);
  }
  assert.equal(helpers.countLabel(0, "outcome"), "0 outcomes");
  assert.equal(helpers.countLabel(1, "outcome"), "1 outcome");
  assert.equal(helpers.countLabel(201, "outcome"), "201 outcomes");
  assert.equal(helpers.countLabel(1, "answer"), "1 answer");
  assert.deepEqual(Array.from(helpers.displayAliases("Libertarian distributism", ["Libertarian Distributism"])), []);
  assert.deepEqual(Array.from(helpers.displayAliases("Geoanarchism", ["Geo-anarchism"])), []);
  assert.deepEqual(Array.from(helpers.displayAliases("Italian Left-Communism (Programma)", ["Bordigism", "Bordigism"])), ["Bordigism"]);
  assert.deepEqual(Array.from(helpers.displayAliases("Jacobinism", ["Montagnardism"])), ["Montagnardism"]);
});

test("market profiles distinguish complete evidence from a conditional Lange replay", () => {
  const profiles = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/profiles.json"), "utf8"))
    .filter((profile) => profile.batch === "E1-B02");
  assert.equal(profiles.length, 3);
  const completeProfiles = profiles.filter((profile) => profile.status === "complete independent profile passed for specified model");
  assert.equal(completeProfiles.length, 2);
  for (const profile of completeProfiles) {
    let questionId = data.start;
    let result;
    for (const step of profile.independent_answers) {
      assert.equal(questionId, step.question_id, `unexpected question for ${profile.subject}`);
      assert.ok(step.source && step.reference, `missing evidence for ${profile.subject}: ${questionId}`);
      const choice = data.graph[questionId].choices.find((item) => item.label === step.answer);
      assert.ok(choice, `missing documented answer for ${profile.subject}: ${questionId}`);
      if (choice.type === "question") questionId = choice.id;
      else { result = choice.ideology; questionId = undefined; }
    }
    assert.equal(result, profile.expected_result);
  }
  const lange = profiles.find((profile) => profile.result === "Langean socialism");
  assert.equal(lange.independent_answers, null, "an unresolved ultimate-market answer must not be certified");
  assert.match(lange.status, /qualified/);
  assert.ok(lange.conditional_answers.find((step) => step.question_id === "q_markets").qualification);
  let conditionalId = data.start;
  let conditionalResult;
  for (const step of lange.conditional_answers) {
    assert.equal(conditionalId, step.question_id);
    const choice = data.graph[conditionalId].choices.find((item) => item.label === step.answer);
    assert.ok(choice);
    if (choice.type === "question") conditionalId = choice.id;
    else conditionalResult = choice.ideology;
  }
  assert.equal(conditionalResult, lange.expected_result, "conditional replay checks connectivity only");
  const movedTito = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/profiles.json"), "utf8")).find(p => p.result === "Titoism");
  assert.equal(movedTito.batch, "E1-B21");
  assert.match(movedTito.status, /qualified/, "moving a result must not hide unresolved ancestor scope");
});

test("stateless economic profiles replay locally without claiming unresolved ancestors pass", () => {
  const profiles = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/profiles.json"), "utf8"))
    .filter((profile) => profile.batch === "E1-B03");
  const review = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/stateless-market-review.json"), "utf8"));
  const sources = new Set(review.sources.map((source) => source.id));
  assert.equal(profiles.length, 4);
  for (const profile of profiles) {
    assert.equal(profile.independent_answers, null, "unresolved root routes must not be advertised as complete evidence profiles");
    let questionId = profile.local_start;
    let result;
    for (const step of profile.local_answers) {
      assert.equal(questionId, step.question_id);
      assert.ok(sources.has(step.source) && step.reference);
      const choice = data.graph[questionId].choices.find((item) => item.label === step.answer);
      assert.ok(choice);
      if (choice.type === "question") questionId = choice.id;
      else { result = choice.ideology; questionId = undefined; }
    }
    assert.equal(result, profile.expected_result);
  }
  const tucker = profiles.find((profile) => profile.result === "Tuckerite Mutualism");
  const counterexample = tucker.root_counterexample;
  assert.ok(sources.has(counterexample.source));
  const rootChoice = data.graph[counterexample.question_id].choices.find((choice) => choice.label === counterexample.answer);
  assert.equal(rootChoice.id, counterexample.actual_next);
  const descendants = (id) => data.graph[id].choices.flatMap((choice) => choice.type === "result" ? [choice.ideology] : descendants(choice.id));
  assert.ok(!descendants(rootChoice.id).includes(tucker.result), "the documented root mismatch must stay visible until actually resolved");
  assert.match(review.forks.find((fork) => fork.question_id === "q_ethnic").status, /not signed off/);
});

test("catalogue search finds people and evidence in descriptions in both renderers", () => {
  const client = fs.readFileSync(path.join(projectRoot, "public/ideosorter.js"), "utf8");
  const react = fs.readFileSync(path.join(projectRoot, "app/page.tsx"), "utf8");
  const staticExpression = client.match(/tile\.dataset\.search = (.+);/)[1];
  const reactExpression = react.match(/const searchable = (.+);/)[1];
  const index = (item, expression) => vm.runInNewContext(expression, { item, ideology: item, name: item.name });
  for (const expression of [staticExpression, reactExpression]) {
    const find = (q) => Object.values(data.ideologies).filter(item => index(item, expression).includes(q.toLowerCase())).map(item => item.name);
    assert.deepEqual(find("Kim Il Sung"), ["Juche"]);
    assert.deepEqual(find("MIM Notes 294"), ["Maoism-Third-Worldism"]);
    assert.ok(find("Deng Xiaoping").includes("Marxism-Leninism-MZT"));
    assert.ok(find("Romanian Workers’ Party").includes("National Communism"));
    assert.deepEqual(find("zzzz-no-matching-result-zzzz"), []);
    for (const item of Object.values(data.ideologies)) {
      if (item.quoteSource?.citation) assert.ok(find(item.quoteSource.citation).includes(item.name));
    }
  }
  for (const item of Object.values(data.ideologies)) assert.equal(index(item, staticExpression), index(item, reactExpression));
});

test("approved communist integration preserves theory and replays the moved local profiles", () => {
  const review = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/approved-communist-routing-R21.json"), "utf8"));
  const sources = new Set(review.sources.map(s => s.id));
  const profiles = JSON.parse(fs.readFileSync(path.join(projectRoot, "editorial/profiles.json"), "utf8")).filter(p => p.batch === "E1-B21");
  assert.equal(profiles.length, 2);
  for (const profile of profiles) {
    assert.equal(profile.independent_answers, null);
    let id = profile.local_start;
    let result;
    for (const step of profile.local_answers) {
      assert.equal(id, step.question_id);
      assert.ok(sources.has(step.source) && step.reference);
      const answer = data.graph[id].choices.find(c => c.label === step.answer);
      assert.ok(answer);
      if (answer.type === "question") id = answer.id;
      else { result = answer.ideology; id = undefined; }
    }
    assert.equal(result, profile.expected_result);
  }
  assert.equal(data.graph.q_stalinCope.question, "Can commodity production exist under the socialist mode of production?");
  assert.equal(data.graph.q_classStruggleSocialism.question, "Does class struggle persist within the socialist mode of production?");
  let id = data.start;
  let result;
  // The user explicitly reviewed this complete Classical Marxism route.
  for (const [expected, label] of [["q_privateProperty","No"],["q_markets","No"],["q_communism","Yes"],["q_dotp","Yes"],["q_foco","No"],["q_stalinCope","No"],["q_reform","Yes"],["q_massparty","No"]]) {
    assert.equal(id, expected);
    const answer = data.graph[id].choices.find(c => c.label === label);
    if (answer.type === "question") id = answer.id;
    else result = answer.ideology;
  }
  assert.equal(result,"Classical Marxism");
});


test("R32 source-backed Nazi-strategy forks avoid politics/guerrilla/terrorism false alternatives", () => {
  const q = data.graph.q_naziLarp;
  assert.equal(q.question, "Should racial nationalists borrow communist revolutionary methods?");
  assert.deepEqual(q.choices.map(choice => [choice.label, choice.type, choice.ideology ?? choice.id]), [
    ["Yes", "result", "Nazi maoism"],
    ["No", "question", "q_siegeAcceleration"],
  ]);
  const siege = data.graph.q_siegeAcceleration;
  assert.equal(siege.question, "Should decentralized terrorist attacks accelerate society’s collapse?");
  assert.deepEqual(siege.choices.map(choice => [choice.label, choice.type, choice.ideology ?? choice.id]), [
    ["Yes", "result", "Siegism"],
    ["No", "question", "q_artaman"],
  ]);
  for (const label of ["Nazi maoism", "Siegism", "Agrarian nazism"]) {
    const card = data.ideologies[label];
    assert.equal(card.author, "Editorial description");
    assert.equal(card.quoteKind, "description");
    assert.ok(card.quoteSource.url.startsWith("https://"));
    assert.ok(card.quoteSource.citation.length > 100);
    assert.ok(card.quoteSource.note.length > 60);
  }
  assert.equal(data.graph.q_artaman.question,
    "Should racial renewal center agrarian settlement and rural life?",
    "upstream agrarian fork remains unresolved and should not be silently rewritten");
});
