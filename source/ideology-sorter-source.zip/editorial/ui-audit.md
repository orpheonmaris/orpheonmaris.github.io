# E1 baseline interface inventory and source audit

Baseline: U1.72, live commit `c392596a46f2650e4a93f45b751f6892e2a18dbd`. The inventory was frozen from the isolated draft's baseline `HEAD`, not mutable working files. No project files, live files, browser state, or deployment settings were changed by this audit.

**Inventory: 99 distinct copy units/templates, UI-001–UI-099.** These cover the static site, React mirror, metadata, accessible names, and CSS-generated quotation punctuation. Repeated wording is one unit with all relevant surface/source locations. Graph question/answer/result content belongs to the parent graph inventory. Full mixed-link paragraphs and their separately actionable link labels count separately. Family filter vocabulary is included. Empty decorative alt text, nonlinguistic URLs, and implementation errors logged only to the console are excluded.

All 99 have been read in source. This is an inventory/source review, not 99 final editorial sign-offs. UI-009 and UI-071 have parent-reported live browser reproductions. The parent owns desktop/mobile, visible-focus, and accessibility verification. Missing button labels are a separate missing-copy obligation, rather than an invented baseline string.

## Prioritized findings

| Finding | Unit(s) | Baseline evidence and reproduction | Recommended disposition |
| --- | --- | --- | --- |
| UI-F09 — unnamed Results buttons | Missing-copy obligation | Parent inspected live U1.72: 201 catalog buttons had no accessible names. Search **Libertarian distributism** returned one unnamed button. Static JS553 and React622 set no explicit name; descendants contain the visual title/family. Both CSS copies apply `content-visibility: auto` (public774/app772), which may affect descendant exposure; source alone does not establish that as the browser cause. | Add the canonical result name as each tile's explicit accessible name; preserve existing visual text and layout. Parent implementing and will verify accessibility tree. |
| UI-F01 — singular result count and no announced status | UI-071 | JS596 / React619 always render `Showing N outcomes`; static index113 and React paragraph lack status semantics. Exact search **Libertarian distributism** matches one result and parent reproduced **Showing 1 outcomes** live. **agorism** also matches one; **zzzzzz** matches zero. | Render `Showing 1 outcome`, otherwise `Showing N outcomes`; announce updates without moving search focus. Parent implementing. |
| UI-F04 — aliases repeat the title | UI-009 | JS480–488 / React576–577 print every alias. Parent reproduced **Libertarian distributism → Also known as: Libertarian Distributism**. Data analysis: 42 results have case-insensitive duplicate names; 45 if accent/punctuation variants are also normalized. Three additional normalized duplicates: Geoanarchism, Neolibertarianism, Workers’ Oppositionism. | Suppress redundant display aliases while preserving alias data/search matches. Retain informative alternative names. Parent implementing. |
| UI-F03 — quiz count never narrows | UI-090 | Static index72 / React504 show global total on every question. A four-result endpoint still says **201 possible outcomes**. | Count distinct outcomes reachable from current question, with singular handling. Parent implementing. |
| UI-F02 — singular progress label | UI-088 | JS373 / React528 produce **1 answers completed** after first answer. | `1 answer completed`; plural otherwise. Parent implementing. |
| UI-F10 — focus after transitions not managed | Behavior, UI-015/UI-063/UI-044/UI-051 | `showView`, `renderQuestion`, `choose`, `quizBack`, and `resultBack` hide or replace the active control without calling focus. Quiz has `aria-live`; result view does not. Source establishes lack of management, not the exact resulting browser focus. | Focus relevant view/question headings on navigation and question changes. Verify mouse and keyboard flows, Back, Retake, and result cycling. Parent implementing. |
| UI-F05 — implementation ID tooltip | UI-094 | JS664 passes `item.id` to `makeClickable`, whose line633 sets `cell.title`; React939 uses `title={visual.id}`. Example tooltip: `q_strongmanLegit`. | Replace with **Answer from this question** in both renderers. Parent implementing. |
| UI-F06 — Tree-entry route silently omits earlier commitments | UI-060/UI-086 | `startAtNode` clears history and presents Question 1. A result reached that way receives the local answer history only and calls it an answer route. | Parent's current draft plan: show the unique complete canonical root route and disclose **Includes the earlier choices leading to your starting question.** Preserve local Back history. Verify that note only appears when earlier unanswered choices were added. |
| UI-F07 — Tree action explanation differs between renderers | UI-036/UI-037 | Static: **Legend (click on a box to view it)**. React: **Legend (click a box in the tree to view it)**. A question box actually begins a quiz there. | Minor parity/clarity issue; new action tooltip helps. Any legend rewrite needs exact draft review. |
| UI-F08 — every result image called a flag | UI-092 | JS435 / React548 generate **{name} flag**. Recent Chuang/TC/Endnotes artwork includes journal/composite banners. | Review with each actual asset. Do not claim every image is mislabelled, and do not rewrite unseen art descriptions. Retain as later asset/accessibility work. |

## Behavior checks from source

| Area | Finding and boundary |
| --- | --- |
| Back from completed quiz | Returns to final question, removes that answer, permits replacement. No source logic defect found. Browser exercise still required. |
| Back from catalog/Tree result | Returns to the origin view. Catalog filters remain in source state. No source logic defect found. |
| Retake | Clears history and starts at the root. No source logic defect found. |
| Result cycling | Available for catalog/Tree origin, hidden for quiz result. Each cycle loads the selected result's primary route. |
| Keyboard controls | Native buttons/inputs/selects/details are used. Static Tree cells are custom `div role=button`, tabIndex0, with Enter and Space handlers; React uses native buttons. |
| Visible focus | Native buttons, links, selects, inputs, and summaries have an explicit 3px outline; Tree scroll regions have explicit focus styling. Static custom Tree cells lack an equivalent dedicated rule, so parent must inspect their actual focus indicator. |
| Reduced motion | Both stylesheets include reduced-motion overrides for near-zero animation/transition duration and automatic scrolling. Confirm computed behavior in browser; source indicates intended support. |
| Navigation | Toggle exposes expanded state and Open/Close accessible names. No Escape handler in baseline. Absence is an improvement opportunity, not proof of a trap; parent adding Escape close. Check focus returns to toggle on Escape. |
| Loading/error/empty states | Home has a role=status load-failure sentence. Catalog has loading and zero-match text. React has **No route is available.** fallback; static renders an empty list if a zero-length path occurs. Valid data should never need that fallback. Tree fetch failure has no dedicated player-facing status, only rejected promise; outstanding robustness item if reproducible with blocked tree data. |
| Tree entry | Quiz history is intentionally local on jump; route disclosure must make restored root commitments explicit. |
| Metadata | Static Twitter description includes 180 questions; React Twitter description omits it. Neither is factually inconsistent at baseline, but wording is not identical. All advertised totals match stated baseline 201/180/201 pending parent's graph enumeration. |
| Home and About | Restrained home copy is preserved. About still describes an exploratory game and one complete route. Attribution, GPL source link, and icon credit are present in both renderers. Download archive contents/licensing are parent's package check. |

## Concrete verification set for the draft owner

1. Open Results: every tile should have an explicit canonical accessible name. Search **Libertarian distributism**: read **Showing 1 outcome**; activate its named tile; no case-only repeated alias appears.
2. Search **zzzzzz**: count zero plus empty-state sentence; keyboard focus remains in search. Clear query: all 201 outcomes return.
3. Open a result with an informative alias: verify the alias remains visible and searchable. Compare hidden case-only aliases with the same canonical result to ensure search coverage is unchanged.
4. Start quiz, answer once, inspect **1 answer completed**. Visit a terminal fork and compare its displayed remaining count to graph descendants.
5. Use keyboard through Start, choices, Back, completed result, Retake, catalog card, Previous/Next, navigation toggle/Escape, and Tree cells. Verify focus is visible and in the new relevant content after transition.
6. Enter at a deeper Tree question, finish, inspect full root route and disclosure; Back should return only through questions actually visited in this run. Start from root should omit the disclosure.
7. Repeat essential flows on mobile and with reduced motion. Confirm no artwork, color-transition, home-layout, or icon changes.

## Baseline versus draft record

The 99 baseline IDs are frozen. Parent has proposed two new copy strings beyond them: **Answer from this question** (replacement for UI-094's internal-ID template) and **Includes the earlier choices leading to your starting question.** (new route disclosure). Revised plural-sensitive count templates are revisions to existing UI-071/UI-088/UI-090, not new baseline entries. Explicit card names derive from canonical result names already inventoried by the graph manifest. No draft sign-off is implied by this audit.
