# Ideology Sorter — Editorial Round 33

**Private candidate:** `E1-R33-soviet-gateway-20261117` · **U1.104** · **Not published**  
**Live comparison:** U1.103 / R32, GitHub commit [`09d48eae`](https://github.com/orpheonmaris/orpheonmaris.github.io/commit/09d48eae78a3b7eb5ca7fc3de40ca0d8b76faae6).  
**Decision:** Draft ready — awaiting explicit publication approval. No production modifications in this round.

## Editorial diagnosis

The original Soviet gate (`q_nepTime`) treated opposition to *forcible collectivization* as sufficient to be classified as **Bukharinism**, incorrectly equating opposition to administrative violence with support for Bukharin's late-1920s NEP strategy. In [“Dizzy with Success” (2 March 1930)](https://www.marxists.org/reference/archive/stalin/works/1930/03/02.htm), Stalin himself publicly argued collective-farm membership must be voluntary; this is a counterexample to the former exclusivity even though forced collectivization occurred in practice. The 1928–1929 debate instead concerned the pace and form of socialist transition, peasant markets, industrialization and agricultural cooperatives. See Bukharin's *Notes of an Economist* (1928) and Stalin's *The Right Deviation in the CPSU(B)* (1929).

The old `q_classStruggleSocialism` attributed a denial of *any* continuing class struggle under socialism to the Khrushchev/Brezhnev branch. That is contradicted by the [1961 CPSU Programme](https://www.bannedthought.net/USSR/CPSU-CapitalistEra/ProgrammeOfTheCPSU-1961-Marked-OCR.pdf), which describes class struggle during socialist construction while holding that the **dictatorship of the proletariat** had fulfilled its tasks and the USSR had become a **state of the whole people**. The [Chinese Communist Party's 1964 polemic](https://www.marxists.org/reference/archive/mao/works/1964/phnycom.htm) explicitly contests this doctrinal conclusion. The site should distinguish these views, not misquote a historical side as having denied that class struggle ever existed.

## Exact player-facing change

### A. `q_nepTime` — historical economic strategy

**Before**

> Was the Soviet Union under Stalin right to forcefully collectivize agriculture?

| Answer | Former route |
|---|---|
| Yes | `q_classStruggleSocialism` and its nine eventual outcomes |
| No | **Bukharinism** |

**After**

> Should the USSR have kept the NEP as its main road to socialism after 1928?

| Answer | New route |
|---|---|
| Yes | **Bukharinism** |
| No | `q_classStruggleSocialism` and its nine eventual outcomes |

**New optional explanation (verbatim):**

> The New Economic Policy kept small peasant farms and regulated private trade alongside public industry. This asks whether to prolong that strategy rather than turn to faster collectivization and industrialization—not whether forcing peasants into collective farms was justified.

The *Yes* player commits to maintaining a market/cooperative NEP as the principal Soviet transition after 1928. The *No* player rejects that **strategic priority**, without thereby endorsing forced membership in collective farms.

### B. `q_classStruggleSocialism` — duration of proletarian class dictatorship

**Before**

> Does class struggle persist within the socialist mode of production?

| Answer | Former route |
|---|---|
| Yes | `q_chinaBourgeois` and its seven eventual outcomes |
| No | `q_khrushBrezhnev` → Khrushchev/Brezhnev results |

**After**

> Must the dictatorship of the proletariat continue until communism?

| Answer | New route |
|---|---|
| Yes | `q_chinaBourgeois` and its seven eventual outcomes |
| No | `q_khrushBrezhnev` → Khrushchev/Brezhnev results |

**New optional explanation (verbatim):**

> This asks whether workers’ class dictatorship must remain necessary throughout the socialist transition, rather than becoming a state of the whole people before communism. It does not deny that class struggle occurred during socialist construction.

The *Yes* answer commits the player to maintaining the proletarian dictatorship until communism. The *No* answer permits ending its distinct class-dictatorship character before communism, while retaining a socialist state and party. **Neither answer is simply a statement about whether workers and bourgeois forces historically came into conflict.**

## Route-level impact

The two questions remain in their original graph positions, with no new or deleted ideology. Exactly **10 of 201** terminal paths change their player-facing question and/or Yes/No answer; the other **191** complete paths have byte-for-byte identical sequences. The changed results are: **Bukharinism; Marxism-Leninism; Anti-Revisionist Marxism-Leninism; Maoism; Maoism-Third-Worldism; Marxism-Leninism-Maoism, principally Maoism; Juche; National Communism; Marxism-Leninism (Khrushchev); Developed Socialism (Brezhnev)**.

The precise before/after *full root route* for each of these ten results is in `editorial/route-replay-R33.json` within the source ZIP, and the complete textual patch is supplied separately. The protected `q_khrushBrezhnev` leadership-renewal wording remains unchanged. No result card, artwork, route count, or home-page feature was changed.

## Historical support and honest limits

The strongest documentary test pair is **Bukharin vs. Stalin on post-1928 NEP** (Bukharin 1928; Stalin 1929), and **1961 CPSU vs. 1964 CCP on the whole-people state** (1961 CPSU programme and 1964 Chinese party editorial; the latter is a *party text*, not a quotation authored personally by Mao). The 1977 Soviet Constitution supports the subsequent Brezhnev-period whole-people state doctrine.

**Unresolved, not silently certified:** Juche and Romanian *National Communism* do not have an established, exclusive answer to whether proletarian class dictatorship must continue until communism; an absence of statements in consulted sources is **not** evidence for a No answer. Likewise, most later Maoist, Korean and Romanian currents do not have an independently sourced, definite position on whether the USSR should have continued NEP after 1928. The fork questions are materially improved but **neither is certified as a perfect classifier for every descendant**. The editor's next batch should source these inherited paths or restructure the Soviet gateway. Full-root profiles remain **2/201 independently complete**. This draft is not declared edition-complete.

## Source record (decisive references)

| ID | Evidence and use |
|---|---|
| R33-S01 | [Bukharin, *Notes of an Economist* (September 1928)](https://revolutionsnewsstand.com/2023/04/14/observations-o-an-economist-the-beginning-of-the-new-economic-year-by-nikolai-bukharin-from-international-press-correspondence-vol-8-nos-73-77-october-19-november-2/) — industrial–agricultural balance and NEP strategy. |
| R33-S02 | [Stalin, *The Right Deviation in the CPSU(B)* (April 1929), §IV](https://marx2mao.redspark.nu/Stalin/TRD29.html) — direct contemporary dispute. |
| R33-S03 | [Stalin, *Dizzy with Success* (2 March 1930)](https://www.marxists.org/reference/archive/stalin/works/1930/03/02.htm) — a direct counterexample to forced collectivization as an identity test; official words do not erase coercive practice. |
| R33-S04 | [International Review of Social History (2022), *Blood on the Red Banner*](https://www.cambridge.org/core/journals/international-review-of-social-history/article/blood-on-the-red-banner-primitive-accumulation-in-the-worlds-first-socialist-state/8B6D5DB086D968F16273E80A364CB346) — modern scholarly contextual analysis. |
| R33-S05 | [CPSU, *Programme of the CPSU* (1961), sections on state and socialism](https://www.bannedthought.net/USSR/CPSU-CapitalistEra/ProgrammeOfTheCPSU-1961-Marked-OCR.pdf) — distinguish experienced class struggle from required duration of class dictatorship. |
| R33-S06 | [Chinese Communist Party editorial, *On Khrushchev’s Phoney Communism* (14 July 1964)](https://www.marxists.org/reference/archive/mao/works/1964/phnycom.htm) — direct rejection of the all-people state doctrine. |
| R33-S07 | [1977 Soviet Constitution](https://www.servat.unibe.ch/icl/r100000_.html) — subsequent state-of-whole-people doctrine. |
| R33-S08 | [Romanian 1965 Constitution](https://legislatie.just.ro/Public/FormaPrintabila/00000G0F7VQP8MOZN8X2MRMOZXCHN54F) — evidence of Romanian state ideology, **not** proof of a Yes answer. |

Full sources, periods, and unresolved profiling are retained in `editorial/soviet-gateway-review-R33.json`.

## Tests and coverage

| Check | Result |
|---|---|
| Graph inventory | **183/183** questions reachable, **383** answer destinations |
| Results and complete routes | **201/201** unique and terminal, zero missing nodes or loops |
| Mechanical route replay | **10 changed** as specified, **191** unchanged |
| Synchronized source/public/preview quiz-data | **Passed** |
| Node source tests | **18/19 passed**; the remaining test cannot execute because `dist/server/index.js` is absent from the archived source; not a demonstrated functional failure. |
| Chromium desktop, 1440×900 | Tested root-to-result for Bukharinism, Stalin-period Marxism-Leninism and Khrushchev-period Marxism-Leninism; source route timeline, Back, search singleton, empty state, About, Tree all exercised. |
| Chromium mobile emulator, 390×844 | Same three complete routes and interface operations; reduced-motion emulation and touch enabled. |
| Browser errors and page horizontal overflow | No errors or page-level overflow observed on tested screens. |
| Tree visualization | Opens on desktop and mobile; tested first tree screen. Did not independently locate the communist fork within its very large, scrollable visual graph. |
| Physical devices, accessibility speech, production | Not re-tested. No claim of comprehensive mobile accessibility or post-publication verification. |

In Results, the unique search term “Nikolai Bukharin” yields **“SHOWING 1 OUTCOME”**, and the corresponding Bukharinism entry has no additional aliases. Search empty-state singular/plural was checked. Focus reached the navigation control by keyboard. The source ZIP includes GPL-3.0, attribution, and accompanying editorial files.

**Progress against frozen edition:** 15/183 forks certified (two newly studied forks explicitly **provisional**); 30/383 answer commitments; 48/201 result cards; 2/201 independently evidence-tested complete profiles; 0/6 admitted coverage omissions resolved. The overall edition is **not complete**.

## Deliverables and approval scope

- Private website preview ZIP with all current static files and a matching downloadable source ZIP.
- Complete unified source patch, including editorial notes, fixture, tests and revision bump.
- Source ZIP with the full editable project and retained record.
- Browser screenshots (16), raw browser-test and Node-test reports.

**Publication requires a new, explicit approval of this exact `E1-R33-soviet-gateway-20261117` candidate against U1.103 / `09d48eae`.** Any later edits or change to the live baseline require a revised diff and renewed approval.

**Draft ready — awaiting approval.**
