Ideology Sorter E1 / R28 — private candidate E1-R28-3679a7a6923b
Baseline published U1.98, commit c1662cd5e0d915388d716b2a5634204ee2b67d78
Candidate U1.99. This archive is NOT an approved publication.
Review editorial/REVIEW.html or editorial/REVIEW.md.
Source includes prior editions, frozen inventory, all 201 routes, 2 changed cards, 1 alias clarification, 1 locally tested fork, and validation caveats.
Apply patch only against approved R27 exact source and run the official build in a deployment-capable environment before any publication. Do not deploy without fresh explicit approval.
