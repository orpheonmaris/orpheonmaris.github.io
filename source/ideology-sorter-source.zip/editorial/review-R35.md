# Editorial Round 35 — Agrarian priority, occult classification, and neighboring result descriptions

**Private revision:** `E1-R35-agrarian-priority-20261117`  
**Proposed site version:** U1.106  
**Compared against live GitHub version:** U1.105, commit `cfdc25671107cbb1c0f80f3bfb2ee2c8b89515ac`

No GitHub production/publishing branch, remote branch or live deployment was modified. This is for review and explicitly requires fresh publication authorization. Later approval of a different revision does not authorize this candidate.

## Main finding and exact changes

The old `q_artaman` question was “Should racial renewal center agrarian settlement and rural life?”. Its Yes answer reached Agrarian nazism, while No led to `q_raceLarp` (Esoteric Nazism / National socialism). This wrongly required the esoteric current to deny the importance of rural renewal and also treated mainstream Nazis as implicitly rejecting blood-and-soil ideology. The 1933 Hereditary Farm Law establishes that both Darré and Hitler-led National Socialism promoted a racially restricted peasantry. The documented internal disagreement concerned the **priority of a peasant-centered order versus industrial rearmament**.

**R35 reorders the two tests:**

1. `q_siegeAcceleration` No now leads straight to **`q_raceLarp`**: “Must racial supremacy rest on occult teachings?” Yes → **Esoteric Nazism**. No → **`q_artaman`**. (Earlier q_raceLarp No → National socialism.)
2. `q_artaman` now asks **“Should a peasant-centered social order take priority over industrial expansion?”** Yes → **Agrarian nazism**. No → **National socialism**. (Earlier q_artaman No → q_raceLarp.)
3. New optional explanation at q_artaman: **“This asks which should take priority when rural reconstruction conflicts with industrial expansion, not whether farms and rural settlement matter at all.”**
4. Two edited result descriptions: Agrarian nazism and National socialism each state the trade-off and date the historical representative current. A capitalization-only duplicate alias “National Socialism” was removed because the catalog search is case-insensitive and the card already displays the canonical result.
5. The fixed-layout Tree repositions two question nodes and the two affected result cells without changing the number of rows/columns or any unrelated node coordinate.

This is a present-day answerable policy-priority proposition; a player is not being asked to endorse a defunct party, particular ruler or historical intervention. The categories are not universal: documented fascist currents may overlap across agrarian, esoteric, and racial claims.

## Sources and independent local profiles

- **R35-S01 — Primary law and scholarly editor's introduction:** German History in Documents and Images, [The Hereditary Farm Law, 29 September 1933](https://germanhistorydocs.org/en/nazi-germany-1933-1945/the-hereditary-farm-law-september-29-1933). The law describes protecting hereditary farms and the GHDI introduction expressly contrasts Darré's re-agrarianization programme with Hitler's industrial rearmament priorities. Translation from Louis L. Snyder (1988), pp. 143–144, based on *Reichsgesetzblatt* I (30 September 1933).
- **R35-S02 — Museum historian account:** [Deutsches Historisches Museum, Richard Walther Darré](https://www.dhm.de/lemo/biografie/richard-walther-darre). The timeline records Darré's 1929 and 1930 works; from 1936 the industrial Four-Year Plan overtook agrarian plans, culminating in his political eclipse.
- **R35-S03 — Specialist scholarship:** [Peter Staudenmaier, “Rooted in the Soil?” (2026)](https://www.cambridge.org/core/books/abs/politics-of-nature-in-nazi-germany/rooted-in-the-soil/D31A2B15BF180EF5ECA58E3B06963CA8), pp. 102–136, on competing environmental/economic priorities among Nazi factions.
- **R35-S04 — Historical synthesis:** Richard J. Evans, *The Third Reich in Power* (2005), chapter “The Battle for Work,” on rural ideology displaced by rearmament priorities.
- **R35-S05 — Scholar of esoteric Hitlerism:** Nicholas Goodrick-Clarke, *Hitler's Priestess: Savitri Devi, the Hindu-Aryan Myth, and Neo-Nazism* (1998). Demonstrates that mystical Hitlerism could coexist with biocentric concerns; non-agrarian commitment cannot be assumed.
- **R35-S06 — Primary party platform:** [USHMM, Nazi Party Platform (1920)](https://encyclopedia.ushmm.org/content/en/article/nazi-party-platform), defining the dated mainstream National Socialism result.

Local independent evidence tests: Darré → occult not foundational, peasant order priority → Agrarian nazism; Hitler-led party in its governing industrial phase → occult not foundational, industry priority → National socialism; Savitri Devi → occult foundational → Esoteric Nazism. These are **local** independently sourced profiles, not claims that the entire path from `q_privateProperty` is verified.

## Technical validation

| Validation | Result |
|---|---|
| Reachable questions | 183/183 |
| Answers | 383 |
| Unique outcomes/complete routes | 201/201 |
| Changed routes | 3 |
| Unrelated routes preserved | 198 |
| Layout dimensions and adjacent edges | Pass |
| Node source tests | 20 passed / 21 total (compiled-worker test unavailable) |
| Desktop affected route replays | 3/3 passed |
| Mobile affected route replays | 3/3 passed |
| Back, Retake, search singleton, empty state, About, Tree, focus, reduced motion | Passed in both preview sizes |
| New independently complete root profiles | 0 |
| Scope coverage gaps resolved | 0/6 |

**Editorial progress**: 16/183 locally/source-reviewed forks; 32/383 answer commitments; 53/201 source-audited result cards; 2/201 complete independent profiles; 0/6 admitted coverage issues resolved. The major unresolved branching defect, `q_constitution`, still affects the pro-private-property subtree and is the next intended review batch.

## Included review files

- `editorial/evidence-R35.json`: precise sources, historical profile positions, and before/after node objects.
- `editorial/route-replay-R35.json`: exact old/new route for each affected result.
- `editorial/validation-R35.json`: automated and browser checks with limitations.
- `editorial/record.json`: cumulative decisions, outstanding work and correction of R34c publication status.
- `editorial/current-inventory.json`: every route synced to the candidate; corrects 4 stale historic-route entries in the old review inventory without altering the player-facing routes beyond the three R35 changes.

**Status: Draft ready — awaiting approval.**
