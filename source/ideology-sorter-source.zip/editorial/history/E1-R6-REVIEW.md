# Ideology Sorter — R6 editorial review

**Blocked — terminal scope decision required.** Live U1.77 is unchanged. This round produced an evidence and decision record, not a publishable website patch.

- Record revision: `E1-R6-2a15aca06ad2`.
- Compared with live U1.77, saved version 89, commit `b48f6b87105b78c3ab316e26cd7ca82c79aa6847`.
- Exact website before → after: **no changes** to wording, answers, results, routes, icons or interface. No deployment was attempted.

## The concrete failure

The path currently requires:

1. Generalized private ownership → Yes.
2. State intervention → To protect market exchange.
3. Strictly limited to courts, property protection and defense → **No**.
4. Corporate-privilege ownership programme → No.
5. Land-value-only taxation → No.
6. Unconditional basic income → No.
7. Military democratization → No.
8. Traditional community norms → No.
9. Result: **Right-libertarianism**, represented by the 2016 U.S. Libertarian Party platform.

But §§2.0 and 3.0 of that platform support protective government. A credible **Yes at step 3** leaves only Objectivism and Minarchism. Its representative result disappears. This is an admissible counterexample; it is not a claim that every party member must accept a state. [Primary programme](https://www.lpedia.org/wiki/Document:National_Platform_2016).

## What the neighboring profiles establish

| Profile | Supported commitment | What remains unproved |
| --- | --- | --- |
| Nozick, 1974 | Minimal state protecting rights and contracts | A mandatory rejection of the broad phrase rational self-interest |
| Rand, 1962 | Capitalism with a specific philosophical and ethical basis | That every other minarchist must reject the current ethical question |
| Libertarian Party, 2016 | Private property, rights protection, voluntary association | Rejection of strict minarchy or voluntary traditionalism |
| Rockwell, 1990 | Traditional social authority within voluntary institutions | An obligatory state entrance or coercive enforcement of tradition |

Nozick: *Anarchy, State, and Utopia*, preface p. ix, first two paragraphs ([scan](https://cooperative-individualism.org/nozick-robert_anarchy-state-and-utopia-1974-preface.pdf)). Rand: *Introducing Objectivism*, June 17, 1962, numbered propositions and political paragraphs ([text](https://courses.aynrand.org/works/introducing-objectivism/)). Rockwell: *Liberty* 3(3), January 1990, pp.34–38, particularly the principles and authority discussion ([transcription](https://rothbardrockwellreport.substack.com/p/the-case-for-paleolibertarianism)).

The [Stanford Encyclopedia of Philosophy](https://plato.stanford.edu/entries/libertarianism/) treats libertarianism as a family of views and distinguishes different meanings of right-libertarianism. That supports the umbrella problem; it does not supply a ready-made quiz partition.

## Proposed direction, not an implemented change

Treat **Right-libertarianism as a family label rather than a separate terminal outcome**, preserving one complete route per remaining outcome. This would permit narrower programmes to carry the distinctions. It would require a complete regrouping draft, with any removed leaf accounted for explicitly; simply deleting the leaf and sending its users to Paleolibertarianism would be wrong.

The decision needed is whether that change in the role of this label fits your intended site. Approval of the direction would authorize further drafting only. You would still review the exact questions, destinations and counts before publication.

Rejected shortcuts: moving the same broad leaf under Yes; renaming it after the LP; inventing constitutional libertarianism without a verified distinction; turning voluntary tradition into a forced No; calling Minarchism and Right-libertarianism aliases. The full evidence matrix is in `right-libertarian-scope-R6.json`.

## Checks and progress

Fresh enumeration: **181 questions, 381 answers, 201 results, 201 unique terminating routes**. No missing destinations, cycles, unreachable nodes or duplicate result routes. Both data copies match. All 1046 tracked non-editorial files match the live source baseline byte for byte. The live route conflict was replayed in the browser.

Political sign-offs remain **7/181 forks**, **14/381 answer commitments**, **16/201 scoped result cards**, and **3/201 independent complete profiles**. Connectivity passes are not classification passes. **0/6** admitted coverage gaps are resolved. Four profiles were investigated in this batch; none earns a new complete-route pass.

R5 desktop/mobile checks remain historical evidence for unchanged application code; no new full viewport suite was run for this records-only round. Physical mobile, assistive speech and OS reduced motion remain outstanding. No candidate release or replacement source download was generated; the matching U1.77 source is included unchanged in the review package.

The frozen edition remains open. If this scope decision is deferred, the next independent batch is the Developmentalism / Strongman route (O003). The blocked libertarian items remain open and must not be silently signed off.
