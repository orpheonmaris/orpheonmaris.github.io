# R15 — Draft ready — awaiting approval

Revision E1-R15-d4bd348d9653; candidate U1.86. Baseline U1.85 / native96 / 062f4651460d10c50fb61f067da674c680066f87.

Three card corrections. No questions, answers, routes, result names, artwork, icons or layout changed.

## National Communism

Before: The foetus is the property of the entire society. Anyone who avoids having children is a deserter who abandons the laws of national continuity. — Nicolae Ceaușescu

After: The Romanian Workers’ Party’s 1964 declaration defends each communist party’s right to choose its own course without subordination to a foreign party. It combines national independence with socialist solidarity and rejects a hierarchy of ruling and subordinate parties. This Romanian current locates communist unity in cooperation between equals, rather than obedience to a single international center.

Label: Editorial description. Source: Statement on the Sino-Soviet Dispute, April 22, 1964; passages on equal party rights, non-interference and proletarian internationalism. English extract reproduced by Fordham’s Internet Modern History Sourcebook.

https://sourcebooks.fordham.edu/Mod/1964romania-china.asp

## Juche

Before: The people are the masters of the revolution in each country. It is like putting a cart before the horse that foreigners carry out the revolution for them. The revolution can neither be exported nor imported. — Kim Song Ju

After: Kim Il Sung’s 1971 account of Juche calls for applying Marxism-Leninism to Korean conditions through independent political judgment, an economy built mainly on domestic resources, and national self-defense. It places these principles under the Workers’ Party of Korea’s leadership. Self-reliance does not mean complete isolation: the account explicitly supports international cooperation between independent countries.

Label: Editorial description. Source: Answers to the Questions Raised by the Iraqi Journalists’ Delegation, first answer. Foreign Languages Publishing House, Pyongyang, 1971; transcription by Marxists Internet Archive.

https://www.marxists.org/archive/kim-il-sung/1971/x01/x01.htm

## Marxism-Leninism-MZT

Before: It doesn't matter whether the cat is black or white, as long as it catches mice. — Deng Xiaoping

After: Deng Xiaoping’s reform programme retains Communist Party rule while using markets, foreign investment and economic experimentation to develop socialism. His 1992 talks judge reforms by productive development, national strength and living standards, rather than treating markets as inherently capitalist. Unlike the Maoist currents that describe the post-Mao reforms as capitalist restoration, this position defends them as socialist development.

Label: Editorial description. Source: Excerpts From Talks Given in Wuchang, Shenzhen, Zhuhai and Shanghai, January 18–February 21, 1992, sections I–II. Marxists Internet Archive; translator unidentified. Editorial paraphrase.

https://www.marxists.org/reference/archive/deng-xiaoping/1992/179.htm

National Communism adds the searchable alias “Romanian national communism”; spelling-only duplicate remains suppressed in display.

## Route findings

The primary people’s-war gate fails for a US MIM adherent; Sison conditions strategy on national circumstances. Merely adding “universally” excludes both; “where appropriate” does not prove the other currents reject it. Romanian independence does not establish rejection of self-reliance, and Kim explicitly permits cooperation. Deng’s socialist markets also remain in tension with the No-markets ancestor. Full evidence, required root routes for all seven descendants, and rejected repairs are in strategy-national-review-R15.json. No new complete-profile or fork pass claimed.

## Verification and scope

182 questions, 382 answers, 201 results, 201 unique terminating routes. All graph and tree-layout bytes/objects unchanged from R14. Build and 13 tests passed. Payload168797 bytes; bounded budget increased by3000 bytes to accommodate three descriptions and citations. Desktop/mobile checks recorded in verification.json. Corresponding source download and complete binary diff included.

Progress: 27/201 scoped cards; 9/182 forks; 18/382 answer commitments; 3/201 independent complete profiles; 201/201 connectivity; 0/6 admitted omissions resolved. Edition remains incomplete. Next: wider regrouping of national independence, reform and strategy, including market ancestors.
