# R12 cumulative draft review

**Draft ready — awaiting approval**

Revision `E1-R12-43f92e17b237`, candidate U1.83. Live baseline U1.81/version93, commit`e2446f2f34961394bbfe67465855d5825857c79e`, tree`4c9d3f1879e93ec17ea6674e9cd24d85e1e17dda`. Live homepage and native version confirmed. Exact recovered baseline tree matches. Isolated local Git repository, no remote, hooks disabled. Nothing published.

R11 was not approved or published. This package includes its two card corrections plus R12; approval would cover all changes listed here. The previous R11 review remains in history.

## Exact question revision

Before: **Was the Chinese revolution a democratic-bourgeois revolution?**

After: **Did China under Mao fail to establish socialism?**

Yes → Anti-Revisionist Marxism-Leninism (scoped to late Hoxha).
No → existing protracted people’s war question.

New optional explanation: **Consider the whole period of Mao’s rule, not just the revolution’s initial democratic stage.**

Mao explicitly calls the initial stage bourgeois-democratic in1940 and affirms socialist revolution and construction in1957. Late Hoxha instead denies that Mao’s China established socialism. The1981CPC resolution also affirms socialist transformation by1956. These establish the currents’ positions; they do not independently adjudicate China’s actual social relations.

## Exact card revisions

### Stakeholder capitalism

Before: In fact, there is not a single key technology behind the iPhone that has not been state-funded. — Mariana Mazzucato 🐛

After: In the Davos Manifesto 2020, companies serve employees, customers, suppliers, communities and shareholders. Their performance includes social and environmental responsibilities as well as financial returns. This concerns corporate purpose, not whether the state or private investors own a company; it can coexist with state capitalism.

Attribution: **Editorial description**. Source: [Davos Manifesto 2020](https://www.weforum.org/stories/2019/12/davos-manifesto-2020-the-universal-purpose-of-a-company-in-the-fourth-industrial-revolution/). Klaus Schwab, Davos Manifesto 2020, 2 December 2019, sections A–C. This card scopes the WEF formulation; it does not represent every stakeholder theory.

Aliases before: ['Stakeholder Capitalism']; after: [].

### State capitalism

Before: A society to be successful must maintain a balance between nurturing excellence and encouraging the average to improve. — Lee Kuan Yew

After: State capitalism combines state ownership of capital with commercial enterprise. In Singapore’s Temasek model, described in 2013, the government owns the investment company but does not direct its individual investment decisions. This concerns ownership and investment governance, not a rejection of responsibilities to workers, communities or other stakeholders.

Attribution: **Editorial description**. Source: [Temasek: ownership and governance (2013)](https://www.temasek.com.sg/en/news-and-resources/news-room/speeches/2013/speech-by-mr-lim-boon-heng-chairman-of-temasek-to-the-4th-annual). Lim Boon Heng, 4th Annual Sovereign Wealth Fund Conference, 5 December 2013: opening description; Government as a shareholder; social responsibility. Singapore is one model, not a definition of all state capitalism.

Aliases before: ['State Capitalism']; after: [].

### Anti-Revisionist Marxism-Leninism

Before: Did Stalin make mistakes? Of course he did. In so long a period filled with heroism, trials, struggle, triumphs, it is inevitable not only for Joseph Stalin personally but also for the leadership as a collective body to make mistakes. — Enver Hoxha

After: Here this result represents Enver Hoxha’s late-1970s position: defend Stalin’s Soviet model while rejecting both Soviet revisionism and Mao Zedong Thought. Hoxha argued that China under Mao never established socialism. Maoists also call themselves anti-revisionist, but reject this assessment of Mao’s China.

Attribution: **Editorial description**. Source: [Hoxha: Imperialism and the Revolution](https://www.marxists.org/reference/archive/hoxha/works/imp_rev/imp_ch6.htm). Enver Hoxha, Imperialism and the Revolution (1978; English edition 1979), Part Two, III, “Mao Tsetung Thought — An Anti-Marxist Theory”, especially the discussion of socialist construction in China. This describes Hoxha’s position rather than endorsing his historical judgment.

Aliases before: []; after: ['Hoxhaism'].

## Affected routes

Anti-Revisionist Marxism-Leninism, Marxism-Leninism-Maoism, principally Maoism, Maoism-Third-Worldism, Maoism, Marxism-Leninism-MZT, Juche, National Communism, Marxism-Leninism.

All eight display the revised question. All destinations and201unique complete routes are retained. The state/stakeholder card routes remain structurally unchanged. Source-backed local answers: late HoxhaYes; Mao1957No; CPC1981No. No full political profile is claimed: the generic Marxism-Leninism, Juche and National Communism categories do not establish one uniform answer, and earlier market/strategy gates remain open.

## Decisive references

- [Mao, On New Democracy, January1940, sectionsIII–IV](https://www.marxists.org/reference/archive/mao/selected-works/volume-2/mswv2_26.htm): Initial stage explicitly bourgeois-democratic; socialism is the subsequent stage.

- [Hoxha, Imperialism and the Revolution,1978; English1979, PartTwoIII, discussion of socialist construction](https://www.marxists.org/reference/archive/hoxha/works/imp_rev/imp_ch6.htm): Late Hoxha rejects the claim that Mao led China onto a genuinely socialist course. This source establishes his position, not historical truth.

- [Mao, On the Correct Handling of Contradictions Among the People, speech27February1957, revised for publication19June1957, sectionI](https://www.marxists.org/reference/archive/mao/selected-works/volume-5/mswv5_58.htm): Affirms socialist revolution and construction, while recognizing continuing contradictions.

- [CPC Resolution on Party History,27June1981, section on basic completion of socialist transformation](https://www.marxists.org/subject/china/documents/cpc/history/01.htm): Reform-era CPC also affirms socialist transformation by1956. Opposition to the Cultural Revolution does not imply accepting Hoxha’s assessment.

## Checks and progress

Build and13/13tests pass.182questions,382answers,201results and201unique terminating routes agree. No destination changes. Desktop and390pxmobile root replay, both revised exits, optional explanation, Back, Retake, expanded route, useful alias search and singular count checked. Keyboard Tab focus has a visible solid outline; Enter activates the answer. Mobile body and scrollWidth both390px. Artwork, color transitions and icon style retained. Reduced-motion CSS retained; OS reduced-motion runtime, physical devices and complete assistive-technology pass remain outstanding.

Scoped card claims23/201; final scoped forks9/182; answer commitments18/382; independent complete profiles3/201; admitted gaps0/6 resolved. The corrected question does not certify all its descendants. Connectivity201/201 is a separate measure.

R12adds672payloadbytes overR11,1974overlive. Budgets become167000quizbytes/297000staticcorebytes. Licensing and attribution preserved; matching source download included. Full patch is against liveU1.81 and includes both unpublished rounds and editorial history.

Next: China/people-war descendant scope and the mocking Maoism-Third-Worldism card. State/stakeholder regrouping remains unfinished ordinary editorial work, not an external blocker. EditionE1is not complete. Publish only after explicit approval of this exact cumulative revision.
