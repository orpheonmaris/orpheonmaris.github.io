# Ideology Sorter — private editorial draft E1-R2-8348eb4f883c

**Draft ready — awaiting approval.** Candidate U1.74 against live U1.73 / a4b95d308c7994499cd395d3a7cc2f44e19b5b83 / saved version 86. No publication attempted.

Three revised questions, one added question, four scoped result cards. Exact before-and-after text and destinations are in changes.json; the complete human-readable review is supplied as Ideology-Sorter-E1-R2-Review.html. Evidence and counterexamples: market-review.json. Frozen inventory remains inventory.json; current routes and stable-ID lineage are current-inventory.json.

## q_authMarkSoc

Before: Should socialist coordination be exercised through a centralized one-party state?

After: Should public institutions have authority beyond voluntary agreements?

- Yes → q_guilds
- No → q_mutual

Optional explanation: This means public bodies can make laws for everyone in an area. Shared rules and collective self-defence can also exist without that authority.

## q_guilds

Before: Should socially owned enterprises compete in markets?

After: How should prices between enterprises normally be set?

- Through market competition → q_marketPolitical
- Through collective coordination → q_lange

Optional explanation: Choose the usual pricing rule. Market competition can coexist with public regulation and investment; collective coordination sets prices through planning or agreement between representative bodies.

## q_lange

Before: Should a central planning board direct socialist investment and output?

After: Should a planning board normally adjust accounting prices to balance supply and demand?

- Yes → Langean socialism
- No → Guild socialism

Optional explanation: A planning board raises or lowers the prices used to allocate productive resources when shortages or surpluses appear. This asks about the normal rule, rather than occasional intervention.

## q_marketPolitical

Before: (new question)

After: Should rival parties be allowed to compete for government?

- Yes → Market socialism
- No → Titoism

## Progress

4/181 local forks; 8/381 answer commitments; 4/201 scoped cards; 3/201 complete independent profiles, plus one qualified Tito profile; 201/201 connectivity routes. Four anarchist internal routes and global ancestors remain open. No admitted coverage issue is closed (0/6).

Build and 11/11 tests pass. Desktop and 390×844 CSS responsive checks pass for the affected controls and routes. Reduced motion is source-checked; physical mobile, OS preferences, assistive speech and the separate React runtime are not claimed tested.

## Approval

Publish only this exact reviewed revision after explicit authorization. A changed draft or baseline requires a new review. Next batch: the four stateless market outcomes, with protected property wording and its Tucker counterexample preserved.
