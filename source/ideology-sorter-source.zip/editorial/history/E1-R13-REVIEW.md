# R13 — Draft ready — awaiting approval

Draft: E1-R13-473c7e595cd4 (candidate U1.84). Baseline: U1.83 / native94 / commit 1bd7c13c9618eac26cbc6cba80164df1b3270e94.

## Exact change

Maoism-Third-Worldism before:

> I already know everything about the White Man, and he knows nothing about me.

Author: Some dumb kid.

After, labeled Editorial description:

> The Maoist Internationalist Movement’s 2004 programme argues that imperialist profits sustain a privileged labor aristocracy across oppressor nations, making those workers an unreliable base for communist revolution. It instead centers the Third World proletariat, defends Mao’s Cultural Revolution, and dates capitalist restoration in China to 1976. Its distinctive claim concerns workers’ class position under imperialism, not a blanket judgment about individuals based on race.

Source: [MIM programme (2004)](https://www.prisoncensorship.info/archive/etext/mn/html/mn294.html) — MIM Notes 294, January 1, 2004, p. 2, “What is MIM?”, points 1–3.

Add “Maoist Internationalist Movement (MIM)” as a useful alias. Preserve existing spelling variants for search; the existing display filter hides redundant variants. Name, artwork and every question/answer/destination are unchanged.

## Affected route

1. Should generalized private ownership of productive property be preserved? → **No**
2. Should market exchange remain a lasting institution after capitalism? → **No**
3. Should post-capitalist society ultimately be classless, stateless, and moneyless? → **Yes**
4. Should the transitional period take on a state-form? → **Yes**
5. Can a proletarian movement’s electoral victory begin the transition in developed countries? → **No**
6. Should guerrillas launch revolution before a mass party is built? → **No**
7. Can commodity production exist under the socialist mode of production? → **Yes**
8. Was the Soviet Union under Stalin right to forcefully collectivize agriculture? → **Yes**
9. Does class struggle persist within the socialist mode of production? → **Yes**
10. Did China under Mao fail to establish socialism? → **No**
11. Should protracted people’s war be the primary revolutionary strategy? → **Yes**
12. Is protracted people’s war universally applicable? → **No**
13. Is the working class of the imperial core principally counterrevolutionary? → **Yes**

## Review outcome and limits

The card now represents a documented historical profile. The whole seven-result people-war subtree was read. The class-analysis fork and universal-war gate remain open: support for armed revolution does not establish a position on universal PPW, and Sison's revolutionary international working-class account differs from MIM's class analysis. No invented No answers or full-route certification.

## Checks

Build and 13 tests passed; 182 questions,382 answers,201 results,201 unique terminating routes. Static payload166646bytes remains below167000budget. Root replay, result source, Back, Retake, route display, keyboard focus and MIM single-result search checked. Card visually checked on desktop and390px iframe. Physical mobile and OS reduced-motion runtime remain untested. Existing interface/coverage inventory carried forward.

Progress:24/201 scoped card claims;9/182 final local forks;18/382 answer commitments;3/201 complete independent profiles;201/201 mechanical routes;0/6 admitted gaps resolved. E1 is not complete.

Next: evidence-backed repair of people-war and class-analysis gates; preserve existing routing until a defensible exclusive grouping is ready. No external access blocker asserted.

No production edit, push, saved version or deployment occurred. Approval applies only to this exact draft; baseline drift requires fresh review.
