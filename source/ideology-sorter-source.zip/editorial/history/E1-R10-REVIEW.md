# Ideology Sorter — R10 private draft

**Draft ready — awaiting approval**

Draft **E1-R10-02a4924c18c6**, candidate **U1.81**, compared with live **U1.80**, saved version **92**, source commit **1a6c1e0603607e0fbf1a9e32fb778f5394bad966**. The recovered editable baseline matches live Git tree **9beca4493a2af31f990843da8fa43ba83b67d0cc** exactly. The private copy has no remote and disabled Git hooks. No push, hosted save, merge or deployment occurred.

This round read the occupational-participation subtree and tested replacement distinctions. The broad regrouping did not survive the counterexamples. The finished draft is a bounded land-policy and card correction, not a claim that the twelve-result routing problem is solved.

## Exact question and answers

| Item | Live U1.80 | Private U1.81 |
| --- | --- | --- |
| Question | Should all land be owned and loaned by the state? | Should land-value taxation replace all other taxes? |
| Yes | National georgism | National georgism |
| No | Should extensive welfare be conditional on political compliance? | Same destination |
| Optional explanation | None | Tax the land itself, not buildings or other improvements. This collects land rent for public use without requiring the state to take over land titles. |

Yes commits to a single land-value tax replacing other taxes. No rejects that replacement; it does not reject land-value taxation as part of a mixed tax system.

## Exact result card change

Old quotation: “How can a man be said to have a country when he has not right of a square inch of it?” — Henry George.

New text, labeled **Editorial description**:

> An authoritarian nationalist application of Georgist land policy: replace other taxes with a tax on land value, excluding improvements, while retaining private titles. This is a composite label; Henry George’s economic proposal does not make him an advocate of authoritarian nationalism. State ownership of businesses is a separate issue.

New source link: [Progress and Poverty, VIII.2 (1879)](https://www.econlib.org/library/YPDBooks/George/grgPP.html?chapter_num=35). Its citation states: “Henry George, Progress and Poverty (1879), Book VIII, chapter 2, “How Equal Rights to the Land May Be Asserted and Secured”; 1912 edition. The source supports the land policy, not the authoritarian political combination.”

The label, banner, family and property branch remain unchanged. This keeps the existing outcome while making clear that the political combination is an editorial composite, not George’s own documented politics. The distinct current and its full route remain unpassed.

## Evidence and limits

George’s 1879 text, Book VIII chapter2, distinguishes public land leasing from his preferred tax mechanism. His 1886 labor-nomination letter supports electoral political action, so it cannot establish the inherited Strongman route. Singapore’s IRAS historical record supplies a local countercheck: its1960s tax system retained non-land taxes. None of this establishes that every broad state-capitalist or stakeholder programme must reject a single land tax.

The other decisive finding is Lee’s13May2011 NTUC speech: union leaders shape policy through statutory boards. That contradicts the existing No required at q_corpo. Chesterton’s guild discussion provides another compatibility case. Planning, occupational participation and state ownership can coexist; changing participate to primarily or offering those as exclusive options would conceal the problem.

Precise sources, all seven descendant commitment checks, three partial evidence profiles, rejected replacement gates and unresolved label questions are recorded in `editorial/land-policy-review-R10.json`. R9’s limited local passes are retained. No new complete independent profile or final fork pass is claimed.

## Affected routes

Seven displayed routes contain the revised question: **National georgism; Social Autocracy / Social Authoritarianism; Stakeholder capitalism; State capitalism; Megacorporatocracy; Corporatocracy; Autocratic capitalism**. Their question IDs, answer labels and destinations are unchanged. The other **194** displayed routes are identical. Full before/after paths are in `editorial/route-replay-R10.json`.

National georgism’s retained route is: generalized private ownership Yes → public goals → Strongman → fixed programme Yes → racial supremacy No → total state direction No → occupational participation No → dispersed families/guilds property No → revised land question Yes. This is the generated game route, not a verified George profile.

## Checks performed

- Fresh build and **13/13 automated tests pass**. Every destination exists; all **201** results are reachable exactly once; no cycles. **182 questions /382 answers /201 results /201 routes**. No test or size gate weakened.
- Source/public payloads agree. Tree layout, icons and artwork unchanged; all node coverage/adjacency and renderer icon-parity checks pass. Existing check/cross SVG paths were inspected.
- Desktop: root replay, both answers, Back, Retake, nine-answer route, Tree node, keyboard Enter, visible3px focus, Results index and About. Search count is **Showing 1 outcome**; aliases add no redundant label.
- Mobile:390px CSS viewport; question, optional explanation, result and Back checked. No horizontal overflow. Result has a vertical scrollbar and375px content width inside390px frame.
- Existing reduced-motion CSS retained. Physical-device testing, OS reduced-motion runtime, assistive speech and separate React interaction runtime were not performed this round.
- Matching downloadable source regenerated and every member checked byte-for-byte. GPL and icon attribution retained. The ZIP excludes itself to avoid recursion.

## Progress

| Measure | Signed off / total |
| --- | --- |
| Scoped local forks |9 /182|
| Local answer commitments |18 /382|
| Scoped card claims |20 /201|
| Complete independent profiles |3 /201|
| Connectivity routes |201 /201|
| Admitted coverage issues resolved |0 /6|

R10 adds one factual question correction and one attribution correction, but does not increase final classification sign-offs. The frozen scope and six admitted gaps carry forward unchanged. No edition-completion claim is made.

Next batch: establish dated State capitalism and Stakeholder capitalism profiles under q_soe/q_zeBugz, separating public ownership, investment authority and company obligations before resuming the wider regrouping. These are outstanding research tasks, not an external access block.

## Approval boundary

Implementation SHA256: `02a4924c18c6945ea2badbbe3214f0be05c09e3802f572e25fd5fb6df820c83c`. The package contains the complete Git binary patch, readable implementation diff, exact source ZIP, this review, records and manifest. Publishing requires approval of this exact revision. A changed draft or live baseline requires an updated diff and fresh approval.
