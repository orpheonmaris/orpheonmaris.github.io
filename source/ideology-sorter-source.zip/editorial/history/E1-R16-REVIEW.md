# R16 — Draft ready — awaiting approval

Draft E1-R16-0597d3700499; candidate U1.87. Baseline U1.86 / saved97 / 971936313a31b396f6c67f56afbee17a58a50cbb.

## Exact changes

Search label: “Search ideologies, aliases or authors” → “Search ideologies, people or keywords”.

Search previously covered names, families, quotation authors and aliases. It now also covers quotation/description text, additional descriptions, source labels, citations and notes. “Kim Il Sung”:0→1(Juche). “MIM Notes 294”:0→1(Maoism-Third-Worldism). All existing name/alias/author matching retained. Substring and case-insensitive behavior unchanged.

New control: “Source details”. Before: full bibliographic citation available only as the source link’s title tooltip. After: the same citation appears in an expandable, keyboard/touch-operable section beneath the retained source link. Applies to45cards with references; no empty control on unsourced cards. No citation wording changed.

## Scope and evidence

Live search regression reproduced on U1.86. Native disclosure follows HTML details/summary semantics. Browser tooltip limitations motivate this change; no WCAG1.4.13 violation is asserted. See search-source-review-R16.json for standards references and verification.

No question, answer, political description, quote, result name, route, artwork or icon changes. R14/R15 decisions preserved. All201results gain full-card search;45gain citation disclosure.

The proposed broader Cultural Revolution regrouping was not admitted: the Romanian1964profile predates it, and generic cultural mobilization does not exclude Ceaușescu’s later programme. No unsupported No answer was assigned. The seven-outcome route repair remains unfinished; R15-F01–F04 remain open.

## Checks

Build and14tests passed.182questions,382answers,201results,201unique terminating routes. Graph and ideology contents equal baseline; Tree layout byte-identical. Both renderer search expressions agree for201cards; all45citations find their owners. Desktop Home/Results/card/About/Tree/navigation read; no-match and singular states verified; source disclosure keyboard open/close; Back; no-sourcecard.390px mobile source disclosure and13-answer root replay toJuche passed. Physical mobile, OS reduced-motion setting and React browser runtime were not exercised. Existing reduced-motion CSS is unchanged; no animation added.

Corresponding source download and full binary patch supplied. Progress remains27/201scoped cards,9/182forks,18/382answer commitments,3/201complete independent profiles,201/201connectivity,0/6admitted omissions resolved. Two interface findings repaired. UI ledger arithmetic corrected:116stable records/115active units including the R14explanation and R16control. This is not edition completion.

Next: evidence-backed regrouping of strategy and national independence, including market ancestors. Publication requires your approval of this R16revision.
