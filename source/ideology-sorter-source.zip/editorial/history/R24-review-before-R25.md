# Ideology Sorter — R24 review

**Draft ready — awaiting approval**

Draft **E1-R24-cc48c257f9a4**, candidate **U1.95**. Compared with published **U1.94 / native version 102**, source commit `3a0273f2888a23779ce4c752ca59727c7e55a670`. Live remained U1.94 / native 102 at the final check.

This draft replaces three unsourced result-card quotations with dated, sourced descriptions. **Routing is unchanged.** The pro-property gateway and neighboring forks remain unresolved; this round does not certify their political accuracy. No push, saved version or deployment occurred.

## Exact player-facing changes

Names, artwork, aliases and result destinations remain as they are. Each old quotation and personal attribution below is replaced by the complete paragraph shown, labeled **Editorial description**, with a source link, expandable **Source details**, and the note **Sourced editorial summary; not a quotation.**

### Neoliberalism

**Before**

> The most important single central fact about a free market is that no exchange takes place unless both parties benefit.

Attribution: Milton Friedman. No source attached.

**After**

Milton Friedman’s 1962 liberalism centers private property, competitive markets and limits on government power. Government still enforces market rules, addresses some market failures and supports low incomes through a negative income tax—cash payments below an income threshold. Unlike a strictly minimal state, this program allows a public income floor. It does not prescribe one foreign policy.

Source link: [Friedman: Capitalism and Freedom (1962)](https://miltonfriedman.hoover.org/objects/57544/capitalism-and-freedom)

**Exact source-details text:** Milton Friedman, Capitalism and Freedom (1962), Ch. II, pp. 34–36, and Ch. XII, pp. 190–195. The income floor depends on the tax-funded amount adopted. Scope: Friedman’s 1962 program; “neoliberalism” has contested broader uses. See Kevin Vallier, “Neoliberalism,” Stanford Encyclopedia of Philosophy, introduction and §6.

### Third way

**Before**

> We must thwart the type of person who sits at home sipping beer rather than producing for society. It's better to make them 50% productive than to let them drink their beer at home.

Attribution: Joseph Jacques Jean Chrétien. No source attached.

**After**

Tony Blair and Gerhard Schröder’s 1999 Third Way combines competitive markets with an active welfare state. It emphasizes education, training, employment and support for enterprise, while linking help for people able to work to responsibilities to take up work or training. Its approach to poverty centers on employment and public services as well as cash support.

Source link: [Blair and Schröder: The Third Way (1999)](https://sites.ualberta.ca/~yreshef/orga417/blair/thirdway.html)

**Exact source-details text:** Tony Blair and Gerhard Schröder, Europe: The Third Way / Die Neue Mitte, 8 June 1999, §§III–IV. This description covers their joint program, including active government, flexible markets, lifelong learning and rights and responsibilities in labour-market policy.

### Neoconservatism

**Before**

> I just want you to know that, when we talk about war, we're really talking about peace.

Attribution: George Walker Bush. No source attached.

**After**

William Kristol and Robert Kagan’s 1996 program calls for American global leadership backed by military superiority, alliances and the promotion of democracy and free markets abroad. It advocates an active international role, including pressure to change authoritarian regimes. Military, diplomatic and economic power serve this goal together; its defining concern is American leadership, rather than a particular domestic welfare policy.

Source link: [Kristol and Kagan: A Neo-Reaganite Foreign Policy (1996)](https://carnegieendowment.org/posts/1996/06/toward-a-neo-reaganite-foreign-policy)

**Exact source-details text:** William Kristol and Robert Kagan, “Toward a Neo-Reaganite Foreign Policy,” Foreign Affairs 75(4), July/August 1996, pp. 18–32; especially “Benevolent Hegemony” and “Three Imperatives.” Carnegie reprint. Scope: this 1996 foreign-policy program, not every historical strand of neoconservatism.

## Affected routes

The card text changes on the quiz, Results and Tree entry points. No answer route changes. Third way has 12 answers; Neoliberalism and Neoconservatism each have 13 answers.

Shared route: private property **Yes** → public goals → elected officials → prediction markets **No** → broadly distributed property **No** → land-rent collection **No** → public-credit dividend **No** → institutional continuity over reform **No** → basic-needs guarantee **No** → extensive regulation **No** → strategic tariffs/subsidies **No**.

| Final fork | Answer | Result |
|---|---|---|
| Job training and higher education | Yes | Third way |
| Job training and higher education, then global power | No, then Economic leverage | Neoliberalism |
| Job training and higher education, then global power | No, then Military readiness | Neoconservatism |

These are the **tree’s required answers**, not attributed answers from the researched profiles. The accompanying research file annotates every ancestor separately and marks missing evidence without inventing No answers.

## Routing findings and editorial decisions

- **q_constitution fails exclusivity.** Protecting markets can be a public goal. Friedman’s own program supplies a counterexample. The 97 current placements are listed in the research appendix: 79 public-goals, 8 market-protection, 10 stateless. Reading their placement is not an independent 97-profile pass.
- **q_needs remains unresolved.** Friedman advocates a public income floor. Its amount is politically chosen; the source does not establish a guarantee meeting every possible basic need. A categorical No is therefore not justified by his opposition to a large welfare bureaucracy.
- **q_mobility joins two policies.** General education, vocational training and higher education must not be silently treated as interchangeable.
- **q_hegemony mixes dimensions.** Kristol–Kagan combines military, diplomatic and economic instruments. A market-liberal domestic program can coexist with this foreign policy. The current neighbors have no verified exclusive disagreement at this fork.
- **Rejected shortcuts:** adding “primarily”; saying “beyond rights and exchange”; or substituting strict minarchy without regrouping its overlapping descendants. No proposed shortcut is treated as approved wording.
- **Protected decisions retained:** all communist theory questions and the explicitly approved Classical Marxism route; q_minarchy “strictly”; the libertarian-distributist mechanism question; all artwork and icons. The approval to consider Right-libertarianism as a family label is retained as a direction, not an implemented deletion.

## Evidence

The cards describe selected programs, not every historical use of each label. The old quotations are not declared fabricated; they are removed because the draft can offer better-supported explanatory prose.

- **R24-S01** — Milton Friedman, [Capitalism and Freedom](https://miltonfriedman.hoover.org/objects/57544/capitalism-and-freedom), 1962. Ch. II, pp. 34–36; Ch. XII, pp. 190–195 (1962/1982 pagination). Primary text; institutional bibliographic record and online transcription.

- **R24-S02** — Milton Friedman, [The Role of Government in Education](https://la.utexas.edu/users/hcleaver/330T/350kPEEFriedmanRoleOfGovttable.pdf), 1955. In Robert A. Solo (ed.), Economics and the Public Interest; opening framework and General Education section. Primary text, university-hosted reprint.

- **R24-S03** — Tony Blair and Gerhard Schröder, [Europe: The Third Way / Die Neue Mitte](https://sites.ualberta.ca/~yreshef/orga417/blair/thirdway.html), 1999-06-08. Sections III (supply-side agenda) and IV (active labour-market policy). Primary joint statement, archived Labour Party page on University of Alberta site.

- **R24-S04** — William Kristol and Robert Kagan, [Toward a Neo-Reaganite Foreign Policy](https://carnegieendowment.org/posts/1996/06/toward-a-neo-reaganite-foreign-policy), 1996-07. Foreign Affairs 75(4), July/August 1996, pp. 18–32; Benevolent Hegemony and Three Imperatives. Primary text, Carnegie authorized reprint.

- **R24-S05** — Kevin Vallier, [Neoliberalism](https://plato.stanford.edu/entries/neoliberalism/index.html), 2026-03-10 revision. Stanford Encyclopedia of Philosophy, introduction and sections 2.3 and 6. Scholarly interpretation.

- **R24-S06** — Wes Whitman, [Libertarian Distributism?](https://isocracy.org/content/libertarian-distributism), 2021-05-15. See limited-state-review.json and entrance-review-R5.json for exact author and source history. Previously reviewed primary position statement.


## Checks and progress

Build passed. **15/15 regression checks passed.** Automatic enumeration: 182 questions, 382 answers, 201 unique terminating routes; zero missing destinations, cycles, unreachable outcomes or duplicate result routes. Graph and Tree layout are byte-for-byte/structurally unchanged as applicable. The matching source archive is included in this draft.

Desktop and 390 × 844 CSS-viewport checks covered all 3 cards, root replay, Back/Retake, keyboard disclosure/focus, Results search and empty states, Tree access, About and counts. “Showing 1 outcome” reads “Showing one outcome.” Alias lists are empty for these 3 cards. Reduced-motion CSS is preserved and inspected; OS-level reduced motion, physical phones and assistive speech remain untested.

| Review category | Reviewed / total | Meaning |
|---|---:|---|
| Scoped result-card claims |33/201|Three added this round|
| Scoped political forks |10/182|No new fork pass|
| Scoped answer commitments |20/382|No new answer sign-off|
| Complete independent profiles |2/201|Three other qualified profiles; 22 partial/failed; 174 pending|
| Connectivity routes |201/201|Connectivity, not classification accuracy|
| Admitted coverage issues resolved |0/6|Scope remains frozen|

The previous source-reading inventory covers 99/99 original interface units, with 18 edition additions and 116 currently active units. These are not 116 final accessibility sign-offs.

## Next batch

Design and source an exclusive regrouping of q_minarchy and the elected market-liberal area, including the approved Right-libertarianism family-label direction. Resolve domestic economics versus foreign-policy overlap before changing edges; retain exact protected wording unless the user changes that decision.

**Approval boundary:** approval must name this exact R24 revision or directly approve this review. If its content or the live baseline changes, a new diff and fresh approval are required. This is not edition completion.
