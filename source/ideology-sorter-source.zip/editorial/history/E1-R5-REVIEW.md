# E1-R5-71fae2faf3a8 — candidate U1.77

**Draft ready — awaiting approval.**

Live baseline: U1.76 / `cd20e67322e837223f9ccaf0c54510bc8168ae81` / saved version 88. Draft isolated at `/workspace/sites/ideosorter-editorial-e1-r5`, with no remotes and hooks disabled. No publication attempted.

R4 publication is recorded in history/E1-R4-publication.json. This round preserves all 181questions,381 answers,201 results and201 complete routes. No result quotations, names or artwork change.

## What changes

Tree shows loading/failure status and a working Try again button. All 381static Tree boxes become native buttons;180 question boxes expose their answer destinations to assistive technology. Both renderers share an accurate legend and instruction. About no longer claims every branch is already a proven exclusive political distinction.

## Exact before and after

### About: How does it work?

Before: Each answer marks a substantive political position and narrows the remaining possibilities. Every branch ends at one ideology, and every ideology has one complete route through the tree.

After: Each answer narrows the remaining possibilities. Every completed quiz ends at one result, and each result has one complete route through the tree. You can inspect that route on the result card.

### About: How are distinctions handled?

Before: Mere spelling variants appear once, while genuinely different currents remain separate. Questions are written to distinguish positions without announcing the result in advance, and both acceptance and rejection mark meaningful positions.

After: Spelling variants are grouped under one result. Political traditions can overlap, and some results represent a particular author, organization or period. A route shows this game’s distinctions; it does not establish that every adherent would answer the same way.

### Tree legend in both renderers

Before: ['Legend (click on a box to view it)', 'Legend (click a box in the tree to view it)']

After: Tree legend

### Tree

Before: None

After: Select a question to start there, or a result to open its card. Scroll to explore each tree.

### Tree status

Before: Tree view waits for fetch without a player-facing loading state.

After: Loading trees…

### Tree failure status

Before: Uncaught rejected layout promise; failed promise reused on every attempt.

After: The trees could not be loaded. Try again, or browse Results.

Button: Try again

Clear rejected layout promise; re-fetch; retry keeps focus on repeated failure and moves focus to first tree question on success. If the player leaves Tree, completion does not move focus.

### Tree if quiz payload unavailable

Before: No Tree-specific message.

After: The sorter data could not be loaded. Refresh the page to try again.

Hide ineffective retry when required quiz data is absent.

### 180 question buttons in Tree

Before: Arrow labels separate from questions in reading order; custom div role=button in static renderer.

After: {answer} leads to: {destination}; …

Native buttons in static renderer; all question buttons in both renderers receive programmatically associated answer/destination descriptions. Visual node labels and arrows unchanged.

## Political review: Blocked

Six proposed entrance/limited-state regroupings were rejected. The strongest unresolved problem remains the overlapping Right-libertarianism/Minarchism labels and the public-goals/market-protection entrance. No unsupported No answer was inserted. See entrance-review-R5.json for candidates, counterexamples and precise sources. New Rummel 1981/2009 welfare evidence narrows an evidence gap but does not certify his 2005 profile.

The About changes make the site’s claims accurate; they do not repair those classifications or sign them off.

## Verification and progress

Production build and12/12 existing tests passed. 201/201 routes remain unique and terminating. Tree missing-file/repeated-failure/recovery tested; keyboard entry, route disclosure, Back, Retake, search singular/zero, and desktop/mobile layout checked. Every Tree question has an accessible answer description. Matching downloadable source is included. Physical mobile, actual screen-reader speech, React runtime and OS reduced motion remain verification limits.

Progress:7/181local forks;14/381answer commitments;16/201scoped result cards;3/201 complete profiles;114/114cumulative interface copy records read,113active distinct units;0/6admitted gaps resolved. No political progress count was inflated by connectivity or partial cross-period evidence.

Next: E1-B06, establish a defensible scope for Right-libertarianism against Nozick 1974, LP 2016 and Rockwell 1990 before regrouping the entrance. This edition is not complete.
