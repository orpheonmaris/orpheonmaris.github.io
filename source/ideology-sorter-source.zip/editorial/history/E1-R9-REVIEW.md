# Ideology Sorter — R9 private draft

**Draft ready — awaiting approval**

Draft **E1-R9-5ff44069cb3a**, candidate **U1.80**. Compared against live **U1.79**, saved version **91**, source commit **976c7a8f928e99aa047d6f89b7eff946c9a0bc0d**. Live U1.79 was also directly observed in the browser. The editable draft began as an exact copy of that source, including the current downloadable source archive. It has no Git remote and its hooks are disabled. Nothing was pushed, saved as a hosted version, or deployed.

This round repairs two local distinctions. It does not certify their shared ancestors or all historical versions of these traditions. R8's card corrections are already published and remain unchanged.

## Exact revision

**Existing question retained:** “What should anchor economic coordination?”

| Answer | Live destination | Draft destination |
| --- | --- | --- |
| A national production plan | Neosocialism | New planning-purpose question below |
| Organized occupational interests | Existing three-way priority question | Revised state-direction question below |

**New question:** “Should national planning prepare a transition beyond capitalism?”

| Answer | Result |
| --- | --- |
| Yes | Neosocialism |
| No | Developmentalism |

**Replaced question:** “Whose interests should corporatist bargaining prioritize?” → **“Should occupational bodies be directed by the state?”**

| Live answers and destinations | Draft answers and destinations |
| --- | --- |
| State → State corporatism | Yes → State corporatism |
| Labor → Yellow socialism | No → Yellow socialism |
| Business → Developmentalism | Removed here; Developmentalism is reached through the planning question's No answer |

The existing white check and cross icons are reused. Both SVG paths were inspected; both renderers' mapping parity passes. No new illustration or custom answer icon was added.

Question counts change **181 → 182** in data, About, and social metadata. Outcomes and complete routes remain **201**; answer choices change **381 → 382**. Version/cache labels change **U1.79 → U1.80**. All cards, quotations, descriptions, names, aliases, families, artwork, CSS and explicit protected questions are unchanged.

The Tree adds the planning question and repositions four result cells to retain adjacent edges: Neosocialism (3,13)→(3,14), State corporatism (3,14)→(5,13), National distributism (5,13)→(5,11), Voluntaryism (5,11)→(5,10). Coordinates are zero-based. The last two moves affect display only, not routes. Grid size and crossing count remain unchanged.

## Affected routes

Only **Neosocialism, Developmentalism, State corporatism, and Yellow socialism** change. The other **197** complete routes are identical. Full exact before/after paths, including all ancestors, are in `editorial/route-replay-R9.json`.

The retained shared entrance is: generalized private ownership **Yes** → public goals → **Strongman** → fixed ideological programme **Yes** → racial supremacy **No** → state directs every sphere **No** → occupational participation **Yes** → economic coordination.

These retained answers describe the game's path, not verified political commitments of every profile. In particular, the Strongman entrance remains wrong for the early neo-socialist parliamentary programme.

## Why these distinctions

1. **Planning's intended direction:** Park's *To Build a Nation* (1971), Columbia excerpt pp.2–3, defends the 1962 national development plan alongside capitalist development and private enterprise. Desan's historical analysis of early neo-socialism identifies an intermediate planned regime on a socialist trajectory. This supports a local disagreement about planning's purpose. State direction or currently private firms alone does not settle that disagreement.
2. **Control of occupational bodies:** Portugal's 1933 National Labour Statute, arts.33 and41–43, places binding occupational arrangements under state approval. The Yellow federation's appeal printed in Biétry1906, pp.321–324, advocates associations as a counterweight to state power and pursues worker coownership through their own activity. This is a more defensible distinction than exclusive State/Labor/Business interests.

These are editorial inferences from the named programmes. The Portuguese profile is the concrete1933 institutional arrangement; it does not stand for every theorist's eventual associational ideal. The early neo-socialist profile relies on historical scholarship: no claim is made to have independently read its original1933 congress transcript. No new quotation is introduced.

Precise references, source types, answer commitments, close-neighbor countertests, and four independently sourced local answer sequences are in `editorial/coordination-repair-R9.json`.

## Checks performed

- Fresh production build passed. All **13/13** automated tests passed, including the four local evidence replays and existing protected-wording checks. No size or integrity gate was weakened.
- **182 questions,382 answers,201 results,201 unique terminating routes**. Every destination exists, each result is reached exactly once, no cycle or duplicate route; source and public payloads match. Both Tree maps cover every node with adjacent, non-overlapping cells.
- Desktop: replayed all four changed destinations, expanded Developmentalism's9-answer route, tested Back, Retake, keyboard activation and visible focus. Opened revised Tree question and inspected its branch visually.
- Mobile:390px CSS iframe; both new/revised questions and Yellow result checked; document width and scroll width both390px. This is responsive-layout testing, not a physical-device test.
- Results index: Developmentalism search displays **“Showing 1 outcome”**; its card has no redundant alias. Index and Tree both show201 results. About shows201 outcomes,182 questions,201 routes and retains the exploratory-game description and licensing links.
- Existing reduced-motion CSS and styling are unchanged. OS reduced-motion runtime, assistive speech and physical mobile were not retested. Browser logs inspected showed extension-generated metadata errors; no application failure was observed in the exercised flows.
- Matching source archive is regenerated and byte-checked against all included files before packaging. GPL and icon attribution remain intact.

## Progress and outstanding work

| Measure | Reviewed / total | Meaning |
| --- | --- | --- |
| Scoped local forks | 9 /182 | Two added in this draft; ancestors not thereby passed |
| Local answer commitments | 18 /382 | Four added in this draft |
| Scoped result-card claims | 20 /201 | Unchanged this round; not full route certification |
| Complete independent profiles | 3 /201 | Unchanged; four additional local replays only |
| Connectivity routes | 201 /201 | Structural check, not classification validation |
| Admitted coverage issues resolved | 0 /6 | Frozen edition gaps remain open |

The frozen inventory and coverage survey are reused. This is **not** an edition-completion claim.

Remaining issues: the protected private-property root is ambiguous for an eventual socialist transition; early neo-socialism does not require a Strongman; Yellow socialism's full entrance is unproved; the occupational-participation gate does not establish rejection by all No-side traditions; planning and occupational coordination can coexist. The neo-socialist banner's later RNP symbolism also remains mismatched to the early period.

These issues remain scheduled editorial work. They do not prevent proposing the independently supported local repair for review. Next batch: repair the occupational-participation gate across all12descendants, then review the early neo-socialist and Yellow entrances across public goals/governing authority.

## Approval boundary

Approve this exact revision to authorize publication. A later implementation change or changed live baseline requires a new diff and fresh approval. Implementation SHA256: `5ff44069cb3afec9cc9681eb5a17495c8db673b1549b04ec5645a7a83c86683d`. The package also contains a complete Git binary patch, a readable implementation diff, the matching source ZIP, and a manifest identifying the final private source commit. The source ZIP excludes itself to avoid recursion.
