# R11: state ownership and stakeholder purpose

**Draft ready — awaiting approval**

Draft `E1-R11-7778dc20ec5f` / candidate U1.82. Compared against live U1.81, version93, commit `e2446f2f34961394bbfe67465855d5825857c79e`, tree `4c9d3f1879e93ec17ea6674e9cd24d85e1e17dda`. Exact recovered source tree matches live. Private repository has no remote and hooks disabled. Nothing published.

## Exact card changes

### Stakeholder capitalism

Before: In fact, there is not a single key technology behind the iPhone that has not been state-funded. — Mariana Mazzucato 🐛

After: In the Davos Manifesto 2020, companies serve employees, customers, suppliers, communities and shareholders. Their performance includes social and environmental responsibilities as well as financial returns. This concerns corporate purpose, not whether the state or private investors own a company; it can coexist with state capitalism.

Attribution: **Editorial description**. Source: [Davos Manifesto 2020](https://www.weforum.org/stories/2019/12/davos-manifesto-2020-the-universal-purpose-of-a-company-in-the-fourth-industrial-revolution/). Klaus Schwab, Davos Manifesto 2020, 2 December 2019, sections A–C. This card scopes the WEF formulation; it does not represent every stakeholder theory.

Remove redundant case-only alias: Stakeholder Capitalism.

### State capitalism

Before: A society to be successful must maintain a balance between nurturing excellence and encouraging the average to improve. — Lee Kuan Yew

After: State capitalism combines state ownership of capital with commercial enterprise. In Singapore’s Temasek model, described in 2013, the government owns the investment company but does not direct its individual investment decisions. This concerns ownership and investment governance, not a rejection of responsibilities to workers, communities or other stakeholders.

Attribution: **Editorial description**. Source: [Temasek: ownership and governance (2013)](https://www.temasek.com.sg/en/news-and-resources/news-room/speeches/2013/speech-by-mr-lim-boon-heng-chairman-of-temasek-to-the-4th-annual). Lim Boon Heng, 4th Annual Sovereign Wealth Fund Conference, 5 December 2013: opening description; Government as a shareholder; social responsibility. Singapore is one model, not a definition of all state capitalism.

Remove redundant case-only alias: State Capitalism.

## Routes and limits

All182questions,382answers and201unique routes are unchanged. Both affected results retain their existing12-answer routes. Complete before/after data and root paths are in changes-R11.json and route-replay-R11.json. No unrelated wording, artwork, icons or layout changes.

These are card corrections, not a route repair. Temasek’s government shareholding does not mean ministers choose its investments. Lee’s2011 speech endorses union participation in public policymaking, contradicting the occupational-participation No. Corporate stakeholder obligations can coexist with public ownership. A proposed ownership-versus-stakeholder fork would therefore manufacture a disagreement. Simply moving stakeholder capitalism into the elected branch also leaves compatible liberal results excluded. Further private regrouping work remains necessary.

The original Lee quotation is authentic (National Archives Singapore,13August1987,p.3); it was replaced for relevance, not falsely declared misattributed. The iPhone quotation is removed without a claim that it is false. Its technology-funding claim does not define corporate stakeholder duties.

## Checks and progress

Build and13/13existingtests passed.201/201unique terminating routes; baseline graph unchanged. Desktop cards,390px mobile card,no horizontal overflow,one-result search singular,route expansion,Retake andBack checked. Physical mobile,OS reduced-motion and full keyboard/assistive-technology runtime checks remain outstanding; no claim of full interface certification.

Scoped card claims22/201; scoped forks9/182; local answer commitments18/382; complete independent profiles3/201; coverage gaps resolved0/6. Connectivity is not political validation.

Payload grows1302bytes to165283bytes for the two definitions and citations; test budgets rise by2000bytes. Matching source download included; licensing and attribution preserved. Complete patch includes editorial history and matching downloadable source.

Next batch: repair the shared economic/governance entrances using independently specified profiles, without inventing rejection or allowing duplicate routes. This is unfinished editorial work, not an access blocker. Publication requires explicit approval of this exact revision.
