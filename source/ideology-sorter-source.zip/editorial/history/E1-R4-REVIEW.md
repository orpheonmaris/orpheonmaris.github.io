# E1-R4-b4b194e30284 — candidate U1.76

**Draft ready — awaiting approval.** Baseline: published U1.75, source 68a4d0dd1910a89c08d4ad8372b6b9bc2eaaf95e, saved version 87. No R4 publication authorized or attempted.

Eight limited-state result cards now have precise definitions, identifiable primary sources and checked short quotations. One optional corporate-privilege explanation was added; all questions, answer labels, routes, names and artwork stay unchanged. Exact before/after fields: changes.json. Sources: limited-state-sources.json. Counterexamples and answer commitments: limited-state-review.json.

R3 publication is recorded in history/E1-R3-publication.json. The frozen edition inventory remains unchanged.

Functional checks: production build and 12/12 tests passed; 201 unique terminating routes, 181 questions, 381 answers. Desktop and 390 px CSS mobile checks passed for affected content. A generated route is not an independent political profile.

**Blocked for whole-branch sign-off:** q_constitution’s public-goals/market-protection answers overlap; LP 2016 supports minimal-state Yes but its result lies behind No; Foldvary 2014 supports pollution as well as land-value levies; umbrella results overlap; unmentioned policies do not prove rejection. No cosmetic fork rewrites certified. The independently finished card corrections remain reviewable.

Progress:7/181 local forks; 14/381 answer commitments; 16/201 scoped cards; 3/201 complete profiles; 108/108 interface units read, not all signed off; 0/6 admitted gaps resolved. q_bertWar earned a local pass unchanged for Rummel 2005, Rockwell 1990 and LP 2016.

Next: E1-B05, regroup the pro-property entrance and limited-state outcomes against these counterexamples. Preserve protected wording and one route per result. This edition is not complete.

Implementation SHA256: b4b194e30284f1a146e8c573ed5ddf22a0c279a36c5428618ba481e32018c455
