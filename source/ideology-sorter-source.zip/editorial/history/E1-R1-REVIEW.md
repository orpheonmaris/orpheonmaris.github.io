# Ideology Sorter — private editorial draft E1-R1

**Draft ready — awaiting approval.** No production files, remote branches, saved Site versions or deployments were changed.

- Draft revision: **E1-R1-bde4a9b1fa72**; candidate label **U1.73**.
- Live baseline: **U1.72**, commit `c392596a46f2650e4a93f45b751f6892e2a18dbd`, saved version **85**. Rechecked before packaging: unchanged.
- Deployment baseline: `appgdep_6aed7d5cc3848191b5d39762fb930f91`.
- The draft is an independent Git repository with no remotes and hooks disabled. Its local base tree was copied from that deployed source. A complete binary Git patch and matching source archive accompany this review.

## What this round changes

The live Results index exposed 201 unnamed buttons in the browser accessibility tree. This batch repairs access to those results, quiz progress feedback, and incomplete routes after entering through the Tree. It also freezes the first-edition inventory and coverage findings.

| Area | Before | Exact draft text / behavior | Scope |
|---|---|---|---|
| Results search count | Showing 1 outcomes | Showing 1 outcome | All other counts retain the plural, including 0. The count is a polite status region; typing retains search focus. |
| Quiz progress accessible name | 1 answers completed | 1 answer completed | Plural retained for 0 and 2 or more. |
| Quiz remaining choices | 201 possible outcomes | {N} outcomes remaining / 1 outcome remaining | N is the number of outcomes below the current question: 201 at root, 97 after Yes, 104 after No, 6 at the distributist fork. |
| Result aliases | Also known as: Libertarian Distributism (under Libertarian distributism) | That redundant line is omitted. | 45 results have at least one redundant alias hidden. Alias data and search matching remain intact; useful aliases such as Bordigism remain. |
| Results card accessible name | Unnamed button in the live accessibility tree | Each button is named with its canonical result, e.g. Libertarian distributism. | Applies to all 201 cards without adding visible text. |
| Tree question tooltip | Internal identifier, e.g. q_distBert | Answer from this question | All question boxes use the action description. |
| Route after starting midway through Tree | Only answers played after the selected question; e.g. View the 1-answer route | View the 4-answer route, with “Includes the earlier choices leading to your starting question.” | Restores the unique root prefix for the resulting ideology. The note appears only when unplayed earlier choices were supplied. Back still follows only the questions actually played. |
| Keyboard navigation | Transitions can leave focus on hidden or replaced controls; Escape does not close navigation. | View/question headings receive focus; Escape closes navigation and returns focus to its toggle. | React also handles selecting the already-active view and cycling results. Static Tree buttons receive the same explicit 3px visible-focus outline as native controls. |
| Edition label / cache version | U1.72 | U1.73 | Candidate label only. No saved or deployed version has been created. |

Uppercase presentation remains controlled by the existing site style. No political question, answer, destination, ideology, quote, description, artwork or icon has been changed. This is an interface batch, not approval of the current classification tree.

## Affected routes

All 201 outcomes gain named Results buttons. All 180 questions display the number of remaining descendants. Forty-five result cards suppress at least one redundant alias while preserving their searchable metadata. Tree entry can affect any partial quiz; the full unique route is shown with a note when earlier choices were supplied.

Concrete replay: **generalized private property → Yes; state intervention → To protect market exchange; strictly limited state → No; corporate privileges/small owners → Yes → Libertarian distributism**. Starting at the last question now shows this same four-answer route, with the added note. Back returns to that question. Starting at the opening question shows no added-prefix note. Destinations and political wording are unchanged.

## Frozen edition and progress

| Item | Reviewed / total | Meaning |
|---|---:|---|
| Interface copy | 99 / 99 | Read in source; not 99 final sign-offs |
| Coverage survey | 201 / 201 results | Both property branches and every metadata family surveyed |
| Connectivity | 201 / 201 routes | Unique result, valid destination, termination |
| Political forks finally reviewed | 0 / 180 | Findings recorded; no political branch signed off |
| Answer commitments finally reviewed | 0 / 380 | Pending systematic descendant tests |
| Result claims finally reviewed | 0 / 201 | Quotes, profiles and neighbors still require review |
| Complete independent profiles | 0 / 201 | Three partial/failed evidence profiles recorded |
| Admitted coverage issues resolved | 0 / 6 | Research-qualified issues, not automatic new leaves |

The six frozen coverage issues are **Christian democracy; classical Justicialism (1950); Kemalism (1931–38); Ujamaa (1967); Nkrumah’s revolutionary Pan-African socialism (1968); Ambedkar’s constitutional state socialism (1947)**. Each has a documented constituency, nearest existing results, a substantive candidate distinction and overlap limits. Resolution may be a profile or description within an existing outcome; none is certified for insertion. Sun’s Three Principles was withdrawn from the proposed gaps because **Tridemism already represents it**; its route is now an audit issue. Deliberate exclusions are retained.

## Research findings queued

The broad public-goals/market-exchange fork can exclude the site’s own Neoliberalism representative, Friedman. Developmentalism is forced through a Strongman answer despite democratic examples. Mao’s new-democratic account conflicts with the current democratic-bourgeois fork. Falange’s private-property programme and Sun’s regulated-capital programme conflict with their current anti-property placement. These are recorded counterexamples, not silently rewritten questions.

The next bounded political batch is the **eight-result market-socialist subtree at q_authMarkSoc**, including its opening-property and market-exchange constraints. The recorded early Lange profile is excluded by the single-party gate. Its actual buttons are Yes / No / The state should not exist; obsolete icon mappings must not be mistaken for current answer wording.

Precise political references and limits are in `editorial/coverage-pro.json`, `coverage-anti.json` and `triage.json`. Examples include Friedman, *The Role of Government in Education* (1955), opening role-of-government paragraphs; Mao, *On New Democracy* (January 1940), III–IV; Falange’s 1934 programme, §13; and Sun/KMT’s January 1924 Declaration, II(2)–II(3). Independent evidence tests are distinguished from mechanically generated routes.

## Decisive sources for this batch

- [W3C: Name, Role, Value](https://www.w3.org/WAI/WCAG21/Understanding/name-role-value), SC 4.1.2: programmatic names and roles for controls.
- [W3C: Button has non-empty accessible name](https://www.w3.org/WAI/standards-guidelines/act/rules/97a4e1/).
- [W3C: Focus Order](https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html), intent and logical navigation.
- [W3C: Status Messages](https://www.w3.org/WAI/WCAG21/Understanding/status-messages), search-result feedback without moving input focus.
- Direct browser comparison of live U1.72 and isolated candidate, plus the frozen graph and both renderers. These checks do not claim full WCAG compliance.

## Verification and limits

The final production build and **10/10 tests** passed. Enumeration checked 180 questions, 380 answer destinations and 201 unique terminating results; index, Tree, canonical routes and advertised totals agree. Every answer icon remains assigned and the two renderers agree. **1,581 partial-start cases** preserve played answers when restoring canonical routes. Data comparison confirms the only quiz JSON change is the version label. All corresponding-source ZIP entries are checked against the draft after packaging.

Desktop testing covered named result cards, one/zero-result searches, informative aliases, heading focus, keyboard answers, Back, Retake, Escape, Tree entry and complete route disclosure. At a **390 × 844 CSS viewport**, home, quiz, result/route, search, About and Tree were inspected; Results fits without horizontal page overflow. This is browser responsive testing, not a physical phone test.

Reduced-motion CSS is preserved and source-checked; OS preference behavior was not emulated. Assistive-technology speech and the React fallback were not exercised at runtime. The React mirror builds and was inspected for parity. Full `tsc --noEmit` still reports unresolved Cloudflare platform types in unchanged db/worker files (`cloudflare:workers`, `Fetcher`, `D1Database`); it is not a clean type-check claim. No fresh political interpretation or quotation has been declared verified merely because its route is connected.

Artwork-specific alternative text, Tree legend parity, failure states and the About page’s broad claims remain queued. The full earlier “Read Chat Context” transcript was not available; explicit visible decisions, deployed source and the wording-protection fixture were used, without treating explored proposals as approvals.

## Approval and continuation

Review the wording above and the complete patch. **“Publish this draft” in direct response to this review authorizes only revision E1-R1-bde4a9b1fa72.** Publication has not been attempted. A changed draft or changed live baseline requires a new review and fresh approval. Continuing editorial work authorizes draft work only.

The compact continuation record is `editorial/record.json`. Read it together with the frozen inventory on every round. This is the first editorial batch, not edition completion.
