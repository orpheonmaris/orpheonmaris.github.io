# R23 — Draft ready — awaiting approval

Revision: **E1-R23-00bbffdd06c1**. Candidate **U1.94**. Compared with live **U1.93 / native 101 / 0f939d5890339e6e1596d39aeeacde322f57f92f**. No live change, source push or deployment.

## Exact player-facing revision

| Item | Before | After |
|---|---|---|
| q_deLeon | Should industrial unions administer the future economy? | Should industrial unions replace parliament in running socialist society? |
| Optional explanation | None | Industrial unions organize workers by industry. This asks whether their elected delegates should replace parliament as society’s central administration, not whether unions should help manage production. |

Yes still leads to **De Leonism**. No still leads to **Orthodox Marxism**. Both labels, both answer icons, all cards, and every destination are unchanged. U1.93 becomes U1.94 in the edition label and asset cache keys. The wording fixture and size allowance are updated for this proposal; core growth is 239 bytes, with prior headroom preserved.

## Evidence and limit

De Leon’s **Socialist Reconstruction of Society**, 10 July 1905, Third Clause, proposes replacing political government with industrial administration. The elected political representatives disband. [Primary text](https://www.marxists.org/archive/deleon/works/1905/050710.htm).

Kautsky’s **The Social Revolution**, 1902, Volume I, Democracy section, says parliament is to be revived through proletarian conquest. That supplies a positive basis for his No to replacement; it does not imply opposition to unions managing production. English publication: Charles H. Kerr, 1903; translation credit as transcribed by MIA: A.M. and May Wood Simmons. [Primary text](https://www.marxists.org/archive/kautsky/1902/socrev/pt1-3.htm).

This is a **local institutional distinction**, scoped to the periods named in the cards. It is not a certification of either complete route. Both traditions can still credibly reject the preceding fixed-mass-party question and reach Classical Marxism. Your explicitly approved Classical Marxism route is preserved. Two possible broader replacements were rejected because they reproduce that overlap; their reasons are in the research record. Lange’s ultimate-market answer remains qualified and is outside this batch.

## Affected routes

Both share: generalized private property **No** → lasting markets **No** → classless/stateless/moneyless goal **Yes** → transitional state-form **Yes** → guerrillas before mass party **No** → commodity production **No** → electoral victory can begin transition **Yes** → fixed mass-party model **Yes** → revised question **Yes: De Leonism / No: Orthodox Marxism**.

The exact Classical Marxism route ends at the preceding fixed-model **No**, unchanged. The route replay JSON contains all 201 paths and separates connectivity from doctrinal validity.

## Checks and progress

Build passed; all 15 existing regression checks passed. Automatic enumeration: 182 questions, 382 answers, 201 results, 201 unique terminating routes; no missing destinations, duplicate results, cycles or topology changes. Desktop and 390×844 mobile-viewport checks passed for both answers, Back, Retake, route display and the explanation. Tree wording agrees. Keyboard focus is visible. Search reads **Showing 1 outcome** for Orthodox Marxism; its alias is Classical Social Democracy. Empty state and About counts agree.

Reduced-motion CSS inspected; OS-setting runtime, screen-reader speech, physical phone and separate React browser runtime remain unverified. A preview launch was initially blocked by automatic review; inspection established local execution with no remote bindings and the supported local preview subsequently ran.

Progress: **10/182 scoped forks**, **20/382 answer commitments**, **30/201 scoped cards**, **2/201 complete evidence profiles**, **201/201 connectivity routes**, **0/6 coverage issues resolved**. One new optional-copy unit is reviewed; 116 active interface units. Edition E1 remains unfinished.

## Package and approval

The package includes this review, the complete binary-capable diff, matching source ZIP, validation, route replays and updated editorial record. Apply the patch only to the named baseline. Do not publish it until the user explicitly approves this revision. If the baseline or draft changes, present a fresh diff.

Next batch: unresolved public-goals/market-exchange entrance O001, including all 97 descendants. Protected q_massparty remains an explicit outstanding decision, not a passed fork.
