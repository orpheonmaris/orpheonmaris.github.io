# R14 — Draft ready — awaiting approval

Draft E1-R14-0ca3d985ccb5 (candidate U1.85). Baseline U1.84 / native95 / ab8c18074b3e1566766671d2a89939892382a49e.

## Exact changes

Move “Did the post-Mao reforms restore capitalism in China?” to immediately after Yes to “Should protracted people’s war be the primary revolutionary strategy?”

- Restoration No → Marxism-Leninism-MZT (Dengism).
- Restoration Yes → “Is protracted people’s war universally applicable?”
- Universality Yes → Marxism-Leninism-Maoism, principally Maoism.
- Universality No → revised class question.
- Class question Yes → Maoism-Third-Worldism; No → Maoism (existing Sison aliases).

Old class question: “Is the working class of the imperial core principally counterrevolutionary?”

New: “Do imperialist profits place most workers in rich countries outside the proletariat?”

Optional explanation: “This asks whether they form a separate privileged class, not just a better-paid section of the working class.”

Answers stay Yes/No. Every card, artwork and unrelated branch stays unchanged. Tree cells are permuted to match the reordered questions.

## Evidence and tests

[S1] Deng Xiaoping, Southern Tour talks, January18–February21,1992, sections I–II. Archive identifies translator as unknown. Paraphrase only. Reform and market mechanisms are defended as socialist development. https://www.marxists.org/reference/archive/deng-xiaoping/1992/179.htm
[S2] El Diario interview, July1988, Ideological Questions and International Politics; Germinal translation with archive modifications. Guzmán describes people’s war as universally applicable and Deng’s course as capitalist restoration. https://redlibrary.info/works/pcp/interview-with-chairman-gonzalo
[S3] MIM Notes294, January1,2004,p2, What is MIM?, points1–3. Restoration in1976; imperial profits create a non-proletarian labor aristocracy. https://www.prisoncensorship.info/archive/etext/mn/html/mn294.html
[S4] Original MIM archived FAQ, undated, paragraphs beginning When we say and Hence. Universal ideology does not entail exporting the Chinese peasant-war strategy to imperialist countries. Date unknown; use as organizational corroboration, not precisely2004. https://www.prisoncensorship.info/archive/etext/faq/maorelevance.html
[S5] MC5, 2001 MIM Congress, Again on the subject of the masses, April19,2001; concluding discussion of class definitions. MIM excludes the labor aristocracy from the proletariat; concerns class position rather than individual political attitudes. https://www.prisoncensorship.info/archive/etext/wim/cong/onmasses01.html
[S6] Sison, On the Question of People’s War in Industrial Capitalist Countries, June5,2019; reprint June6, opening and first section. Industrial proletariat described as majority; rejects universal applicability of Chinese PPW; affirms Chinese capitalist restoration. https://redspark.nu/theory/on-the-question-of-peoples-war-in-industrial-capitalist-countries-by-jose-maria-sison/
[S7] Interview with Sison, Third Worldism question and answer; reproduced primary interview. Explicitly rejects Third Worldist dismissal of imperial-country proletarian revolution; describes exploitation and proletarianization. https://orinocotribune.com/interview-with-comrade-jose-maria-sison/

Four independently sourced local profiles replay successfully from the restoration question. Root replays test connectivity, not all upstream classifications. All13existingtests pass;182questions,382answers,201results,201unique routes. Desktop and390px mobile checks include revised question, outcomes, Back/Retake, Tree entry, keyboard focus, optional explanation and single-result MIM search. Reduced-motion CSS retained; OS preference and physical mobile not tested. Prior whole-interface survey carried forward. Source archive includes matching source and licenses.

Progress remains24/201scopedcards,9/182finalbroadforks,18/382commitments,3/201completeindependentprofiles,201/201connectivity,0/6gaps. R14 adds four local evidence replays and repairs three local forks; broad-label and upstream issues prevent final sign-off. Current distinct interface-copy count114.

## Remaining work

The preceding primary-people’s-war gate still mixes national conditions. Deng’s market position also raises an earlier-route problem. Generic Maoism is broader than the Sison profile. These are unfinished research and classification work, not permission or access blockers. Next batch: the seven-result entrance gate.

No push, save-version or deployment occurred. Approve this exact R14 before publication.
