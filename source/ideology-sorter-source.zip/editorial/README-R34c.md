# E1-R34c-contemporary-national-communism-20261117 — approved-wording preserved; contemporary National Communism fork

**Status: PRIVATE DRAFT — awaiting explicit approval; not published.**

**Live baseline:** U1.104, commit [`001d737e7499cdc99b1f4d7a9c60b1563407b5ed`](https://github.com/orpheonmaris/orpheonmaris.github.io/commit/001d737e7499cdc99b1f4d7a9c60b1563407b5ed). **Candidate:** U1.105. **Supersedes:** unapproved R34 and R34b. Both were drafts, not releases.

## Decisions carried forward

The user rejected the earlier international-party-autonomy fork as overlapping other communist ideologies, then rejected the replacement Moscow-loyalty question as historically limited. The user expressly **liked** the R34b Juche wording and requires every question to be a political proposition someone can uphold today. The proposed revision keeps that Juche wording exactly while giving National Communism an enduring doctrinal distinction.

## Exact before and after — all branch changes

| Item | U1.104 live wording / route | R34c private wording / route |
|---|---|---|
| `q_peopleWar`, **No** destination | `q_natCom` | `q_songun` |
| `q_songun` question | Should self-reliance be the revolution’s primary litmus test? | **Should the supreme leader’s thought be the party’s highest ideological authority?** |
| `q_songun` **Yes** | Juche | Juche (unchanged result) |
| `q_songun` **No** | National Communism | Continue to `q_natCom` |
| `q_natCom` question | Should the revolution’s main priority be the nation’s liberation? | **Should national identity be as fundamental to communism as class?** |
| `q_natCom` **Yes** | Continue to `q_songun` | National Communism |
| `q_natCom` **No** | Marxism-Leninism | Marxism-Leninism (unchanged result) |

**Rejected historical R34b question, not shipped:** Should communist parties be free to reject binding directives from Moscow?

**Optional explanations as displayed:**

- **Juche question:** This means making a leader’s thought binding party doctrine, not simply respecting the leader or following collective decisions.
- **National Communism question:** Yes treats national identity and emancipation as socialist ends alongside class emancipation. No can still support national independence while treating it within an international class project.

### Why the ordering matters

Kim Il Sung, replying to *Yomiuri Shimbun* in January 1972, explicitly rejected the label “national communism” for Juche and defended proletarian internationalism alongside independence. A nation-over-class fork before Juche would therefore be historically misleading. Asking the leader-authority question first allows a Juche adherent to answer Yes without having to adopt the positions of National Communism or reject international solidarity. The following national-identity question then distinguishes two programs without demanding allegiance to a long-defunct international center.

**Nation/class proposition — Yes:** national identity and emancipation are fundamental communist goals alongside class emancipation. **No:** national self-determination may be supported, but remains part of an international class-based program, not a coequal defining political end. These are positions that can be endorsed now, not positions about obedience to Stalin-era Moscow.

**Critical counterexamples:** (1) historical National Communism was heterogeneous and lacks a single canonical program (Dallin, Benko and Hudek); (2) some later Romanian national communists might affirm supreme leader-ideology as well, potentially branching toward Juche; (3) patriotic, anti-imperialist Marxist-Leninists may strongly defend national identity while declining to make it coequal with class in their doctrine. The classification remains **provisional**, not a certified universal partition.

## Full result-card text comparisons

### Juche

**Before — published U1.104:**

> Kim Il Sung’s 1971 account of Juche calls for applying Marxism-Leninism to Korean conditions through independent political judgment, an economy built mainly on domestic resources, and national self-defense. It places these principles under the Workers’ Party of Korea’s leadership. Self-reliance does not mean complete isolation: the account explicitly supports international cooperation between independent countries.

**After — private U1.105:**

> Kim Il Sung’s account of Juche advocates political independence, economic self-reliance and national self-defense, while applying revolutionary theory to Korean conditions. Later party doctrine made Kim Il Sung’s thought the supreme ideological authority. Kim also presented independence as compatible with proletarian internationalism; a Juche supporter need not elevate national over international class interests.

**Decisive sources:** Kim Il Sung, answers to Yomiuri Shimbun (January 10, 1972), Works, vol. 27, pp. 23–30; Kim Jong Il, On the Juche Idea (1982); Jong-sung Kim, From Soviet Origins to Chuch’e (2017), chs. 3–4.

**Editorial qualification:** Kim explicitly rejects “national communism” as a label for Juche in 1972 and affirms internationalism. The leader-authority fork therefore precedes the national-identity fork.

### National Communism

**Before — published U1.104:**

> The Romanian Workers’ Party’s 1964 declaration defends each communist party’s right to choose its own course without subordination to a foreign party. It combines national independence with socialist solidarity and rejects a hierarchy of ruling and subordinate parties. This Romanian current locates communist unity in cooperation between equals, rather than obedience to a single international center.

**After — private U1.105:**

> National Communism treats national identity and emancipation as socialist aims alongside class emancipation, not merely tactics within an international class struggle. It combines communism with a distinctive national outlook. Slovak communists and the Romanian Workers’ Party illustrate different forms. National independence alone does not define this tendency, since internationalist Marxists can support it too. A supreme leader’s thought is not required by every national-communist current.

**Decisive sources:** Benko and Hudek, “Slovak National Communism,” Nationalities Papers 53 (2025): 917–937, DOI 10.1017/nps.2024.71, esp. 918; Alexander Dallin, “National Communism,” International Encyclopedia of the Social Sciences; Zavatti, “Between History and Power” (2020), DOI 10.5209/chco.71890.

**Editorial qualification:** Uses the strong doctrinal sense, in which nationhood and class have equal standing. National Communism has no single program and overlaps some Marxist-Leninisms; this fork is not universally exclusive.

### Marxism-Leninism

**Before — published U1.104:**

> Stalin-era Marxism-Leninism presents Leninism as Marxist theory and revolutionary strategy for the age of imperialism. It centers a vanguard communist party and the dictatorship of the proletariat, and holds that socialism can be built in one country despite continued capitalist encirclement. Its late-1920s Soviet strategy favored accelerated industrialization and expanded collective and state farms over Bukharin’s prolonged NEP approach. This period-specific profile does not define every movement calling itself Marxist-Leninist.

**After — private U1.105:**

> Marxism-Leninism advocates a revolutionary vanguard party and proletarian power as means of socialist transformation. It treats class emancipation as an international project while supporting national liberation and locally adapted strategies. National identity is not a coequal final principle. The Stalin-era Soviet current also held that socialism could be built in one country and rejected Bukharin’s prolonged NEP strategy; those choices do not define every contemporary Marxist-Leninist.

**Decisive sources:** Stalin, Foundations of Leninism (1924), ch. VI, “The National Question”; Communist Party (Germany), Marxism-Leninism: Basic Training (2025), §6.4, “Proletarian Internationalism”; Stalin, “The Right Deviation” (1929) on the NEP.

**Editorial qualification:** Ideal-typical doctrinal position, not denial of national self-determination, patriotism, or political independence. Some Marxist-Leninist currents overlap with National Communism.

## Route and interface impact

Exactly **3/201** complete root-to-result routes change; **198/201** retain their previous question/answer sequence. Juche's route has 14 answers; National Communism and Marxism-Leninism now have 15. The No branch of `q_peopleWar` now goes to `q_songun` and the No branch of `q_songun` goes to `q_natCom`. The Tree coordinates of the two questions and the Juche/Marxism-Leninism result cells were locally rearranged to keep all connections adjacent; all other Tree coordinates are identical.

No icons, flags, banners, visual style, navigation, answer labels, result count, or unrelated ideologies have been changed. Both renderers (editable app data and static site data) contain the same quiz content and the matching source ZIP is bundled in the private website preview.

## Validation

- Source graph: **183/183 reachable questions, 383/383 answer destinations, 201/201 unique results and routes**; no missing endpoints, duplicate results, unreachable questions, or cycles.
- Tree mapping: Node tests passed adjacency, density, crossing, and node uniqueness constraints after the swap.
- Node test suite: **19/20 passed**; 1 cannot run because the archived source lacks `dist/server/index.js` (compiled worker artifact). It has not been counted as a pass.
- Private Chromium preview: desktop 1440×900 and mobile 390×844; **6/6** affected root-to-result replays pass. Result names, route summaries, Back, Retake, navigation, Tree, About, one-result search (`SHOWING 1 OUTCOME`), empty state, visible keyboard focus, and reduced motion checked in both viewports. No JavaScript page errors or document-level horizontal overflow.
- Device limitation: These were headless Chromium device-size previews, not physical phone or real production visits. Browser checks used locally mocked source JSON; no production website actions occurred.
- The three local ideology profiles are not certified as complete, independent whole-route classifications; their inherited ancestor questions and broad family boundaries remain under review.

## Evidence

- **R34c-S01 (peer-reviewed)**: [Benko and Hudek, Slovak National Communism in Interwar Czechoslovakia (2025)](https://doi.org/10.1017/nps.2024.71) — explains nation and class as of equal importance for doctrinal national communism and notes variety across cases.
- **R34c-S02 (primary)**: [Stalin, Foundations of Leninism (1924), The National Question](https://www.marxists.org/reference/archive/stalin/works/1924/foundations-leninism/ch06.htm) — national liberation evaluated within the general struggle for proletarian revolution.
- **R34c-S03 (contemporary primary)**: [German Communist Party, Marxism-Leninism Basic Training (2025), 6.4](https://kommunistischepartei.de/wp-content/uploads/2025/08/Basic-Training_digital-version_2025-11.pdf) — modern party says national-level struggle and patriotism can coexist with proletarian internationalism.
- **R34c-S04 (primary)**: [Kim Il Sung, Works, vol. 27, January 10, 1972](https://www.marxists.org/archive/kim-il-sung/cw/27.pdf) — denies Juche is national communism and insists self-reliance supports proletarian internationalism.
- **R34c-S05 (peer-reviewed)**: [Zavatti, Between History and Power (2020)](https://doi.org/10.5209/chco.71890) — Romanian national-communist legitimation and nationalist historiography.
- **R34c-S06 (academic)**: [Dallin, National Communism, International Encyclopedia of the Social Sciences](https://www.encyclopedia.com/social-sciences-and-law/political-science-and-government/political-science-terms-and-concepts/communism) — explains lack of a single doctrine and how historical versions overlap categories.

## Edition standing instruction and progress

Every fork must now be tested for whether **a person who holds the ideological position today could honestly answer it**. A historical case can be used as evidence but is not a substitute for a timeless political proposition. The archived Soviet-NEP counterfactual and Mao-era Chinese historical assessment are placed in the queue for this future audit; they have **not** been silently rewritten.

Certified forks: **15/183**; certified answer commitments: **30/383**; source-audited result cards: **51/201** (the present three are supplementary reviews, not final certifications); independently complete profiles: **2/201**; resolved admitted coverage gaps: **0/6**. These counts remain unchanged by a provisional local classification revision.

**DRAFT READY — AWAITING APPROVAL.** The published baseline must be checked again before any release, and only this exact private revision may be published after a new explicit authorization.
