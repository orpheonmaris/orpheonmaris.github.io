# Ideology Sorter — Edition 1, Editorial Round 31
**PRIVATE REVIEW DRAFT — NOT PUBLISHED**
**Exact candidate:** `E1-R31-occult-fork-20261116` / proposed `U1.102`
**Current approved live baseline:** `E1-R30-national-socialism-20261116` / `U1.101` / GitHub commit `758a6448e7e62781a6e6dd114c97a219c5c8cb33`
**Scope:** a factual correction to one terminal question (`q_raceLarp`), one result card, its tree label, source annotations, offline tests, and cumulative editorial records. There is no change to production, no new or deleted result, and no reorganization outside this local sibling pair.

## 1. Exact player-facing before and after
### The terminal question
**Before (U1.101)**
> What gives the race its superiority?
- **Biology** → `National socialism`
- **Spirits** → `Esoteric Nazism / Esoteric Fascism`
No optional explanation.

**After (U1.102 private draft)**
> Must racial supremacy rest on occult teachings?
- **Yes** → `Esoteric Nazism`
- **No** → `National socialism`
Optional explanation, previously absent:
> This asks whether a distinct mystical or occult doctrine is necessary to the political theory, not simply whether it uses racial myths, symbols or rituals.

**Meaning of the answers.** *Yes*: the doctrine claims occult/religious teaching is constitutive of its account of racial supremacy (as in representative postwar esoteric Hitlerism). *No*: the doctrine does not require such teaching, even if some adherents use rituals, mysticism, or mythology (the historical NSDAP’s public platform). Biological racism can coexist with either answer; the new fork does not pretend otherwise.

### Esoteric-result card
**Before (U1.101)**
- **Title:** Esoteric Nazism / Esoteric Fascism
- **Aliases:** Esoteric nazism, Esoteric Fascism
- **Displayed quotation:** “We can see into the distant future, because we know it. That's why we do our duty more fanatically than ever, more bravely, obediently, respectably than ever.”
- **Attribution:** Heinrich Luitpold Himmler; no precise card source supplied for this quotation

**After (U1.102 private draft)**
- **Title:** Esoteric Nazism
- **Aliases:** none; *Esoteric fascism* refers to a wider category, not a spelling variant
- **Display type:** sourced editorial description rather than a purported representative quotation
> Esoteric Nazism is a postwar neo-Nazi current associated especially with Savitri Devi and Miguel Serrano. Its proponents recast Hitler as a divine or cosmic figure and interpret Nazi racial ideology through occult doctrine, drawing on selected Hindu and pagan themes. They did not necessarily reject biological racism; what separates this current from the historical Nazi Party's public doctrine is the essential role of esoteric teachings. Esoteric fascism is a broader category, not an alternate name for this narrower current.
- **Source link label:** Goodrick-Clarke (1998; 2001) and Versluis (2013)
- **Optional source-details citation:**
> Arthur Versluis, “Savitri Devi, Miguel Serrano and the global phenomenon of esoteric Hitlerism,” in Occultism in a Global Perspective, ed. Henrik Bogdan and Gordan Djurdjevic (Acumen, 2013), pp. 121–134 (online 5 March 2014); Nicholas Goodrick-Clarke, Black Sun: Aryan Cults, Esoteric Nazism and the Politics of Identity (NYU Press, 2001), chs. 5 and 9; and Hitler’s Priestess: Savitri Devi, the Hindu-Aryan Myth, and Neo-Nazism (NYU Press, 1998), description and introduction.
- **Visible scope note:**
> Scope: principally postwar esoteric Hitlerism, not esoteric fascism in general or the entire historical Nazi movement. The previously displayed Himmler quotation lacked adequate attribution for this specific current.
- **Art and family:** exact existing flag, thumbnail, family `National-authoritarian`, and `Pro-private property` branch preserved
- **Neighboring National socialism result card:** unchanged; its terminal label changes from **Biology** to **No**

## 2. Affected routes and nearby problems
Root-to-terminal path remains nine answers, through:
`q_privateProperty` → `q_constitution` → `q_stateFunctions` → `q_pragmaticStrongman` → `q_racism` → `q_legionaryRenewal` → `q_naziLarp` → `q_artaman` → `q_raceLarp`.
All eight ancestor questions and their answer wording are unchanged. Under the revised ninth answer, **No** reaches **National socialism** and **Yes** reaches **Esoteric Nazism**. Exactly **199 other complete result paths** are byte-for-byte unchanged in their question and answer sequences; the two affected results retain their nine-step upstream paths.
**Do not mistake route connectivity for historical validity.** `q_naziLarp` asks “What form should racial struggle take?” with **Politics / Guerrilla / Terrorism**: these combine broad arena and tactics, which overlap. `q_artaman` asks whether racial renewal should center on agrarian settlement; historical Nazi blood-and-soil rhetoric makes the neighboring general/agrarian division contestable. Both ancestors remain unapproved and unvalidated; the two R31 profiles establish only the terminal choice, not an independently certified nine-answer root route.
The Soviet `q_nepTime` and `q_classStruggleSocialism` gateways are also untouched and unresolved. The protected property-ownership wording and all previously approved routes elsewhere remain unchanged.

## 3. Decisive research and source notes
- **R31-S01 — United States Holocaust Memorial Museum, Nazi Racism.** Historical Nazi regime racial pseudoscience; distinguishes the general platform from esoteric doctrines. https://encyclopedia.ushmm.org/content/en/article/nazi-racism
- **R31-S02 — Arthur Versluis, Savitri Devi, Miguel Serrano and the global phenomenon of esoteric Hitlerism (2013), pp. 121–134.** Postwar esoteric Hitlerism as a cross-cultural occult religiosity. https://www.cambridge.org/core/books/abs/occultism-in-a-global-perspective/savitri-devi-miguel-serrano-and-the-global-phenomenon-of-esoteric-hitlerism/FA5A25553E361411F513A46ACB6E15A3
- **R31-S03 — Nicholas Goodrick-Clarke, Black Sun (NYU Press, 2001), chs. 5 and 9.** Scholarly study of Savitri Devi, Serrano and new esoteric Nazi sects. https://nyupress.org/9780814731246/black-sun/
- **R31-S04 — Nicholas Goodrick-Clarke, Hitler’s Priestess (NYU Press, 1998), description and introduction.** Devi synthesizes racial-biological ideology and divinized Hitler myth, counterexample to biology/spirits exclusivity. https://www.jstor.org/stable/j.ctt9qg323
- **R31-S05 — Julian Strube, Doesn’t Occultism Lead Straight to Fascism? (2019), pp. 225–231.** Warns against exaggerating a universal Nazi occult ideology; distinguishes postwar esoteric neo-Nazism. https://www.cambridge.org/core/books/abs/hermes-explains/doesnt-occultism-lead-straight-to-fascism/37B7E8DA44C5D9FCCB4E2A847FE870E3
- **R31-S06 — Davide Marino and Milan Reith, Pagan Imperialisms: Julius Evola’s Esoteric Collaborationism (Aries 25, 2025), 194–225.** Esoteric fascist traditions beyond Hitlerist neo-Nazism; broad alias cannot be treated as spelling variant. https://doi.org/10.1163/15700593-02502003
**Finding:** Savitri Devi and Miguel Serrano combined racial claims with occult/sacral doctrines; *Biology* versus *Spirits* is a false exclusivity. Scholarship distinguishes such postwar esoteric Hitlerism from the Nazi Party’s general racial pseudoscience. *Esoteric fascism* also includes non-Hitlerist currents, so it is not a legitimate alias for the revised card.
The former Himmler aphorism lacked a precise quotation source tying it to the esoteric-Hitlerist current. It is removed, not reassigned or invented.

## 4. Validations actually performed
- **Automatic graph enumeration:** 182 reachable questions, 382 answers, 201 unique reachable results, 201 terminal routes; no cycles, missing destinations, or duplicate result paths.
- **Two complete Tree layouts:** 179 pro-private-property nodes, 203 anti-private-property nodes; no duplicate layout keys/coordinates; regenerated public JSON exactly matches editable JSON.
- **Change isolation:** only one question node differs from R30; one existing result card is renamed and re-evidenced. All 199 unrelated route sequences are identical to R30.
- **Chromium private desktop + mobile:** 1440×900 and 390×844, each showing both nine-answer results and answer-route displays, source details, Back and Retake, both Tree views, About, catalog search for *Miguel Serrano* (count is **SHOWING 1 OUTCOME**), empty state, keyboard-visible Start focus, and no horizontal overflow or JS exceptions. Mobile test enabled reduced-motion preference.
- **Node test suite:** 17 of 18 tests passed. The remaining compiled-worker test cannot run, because `dist/server/index.js` is absent and production-build dependencies are not installed. **This is not a complete build certification.**
- **Offline browser limitation:** exact HTML/CSS/JS and content JSON from private files were exercised in an in-memory page with images embedded; this avoids network/sandbox restrictions but is not a live-host, production-asset, real-device, or deployment test.

## 5. Edition progress after Round 31
| Editorial dimension | Reviewed / total | Qualification |
|---|---:|---|
| Source-audited forks | **14 / 182** | This is local fork validity only |
| Answer commitments | **28 / 382** | Two local terminal answers added |
| Result cards | **45 / 201** | One previously unsourced esoteric card revised |
| Independently complete root profiles | **2 / 201** | R31 adds two *partial* terminal profiles, not full-route passes |
| Graph connectivity | **201 / 201** | All paths exist; not evidence that all classifications are sound |
| Admitted coverage gaps resolved | **0 / 6** | No new leaves added |
Frozen original scope and previous decisions preserved. Next editorial priority: `q_nepTime` and `q_classStruggleSocialism` (broader Soviet subtree). Secondary local priority: `q_naziLarp` and `q_artaman`.

## 6. Approval boundary and reproduction
1. **Review exact identifier:** `E1-R31-occult-fork-20261116` compared against `U1.101` at `758a6448e7e62781a6e6dd114c97a219c5c8cb33`.
2. Read the accompanying complete text patch and examine the screenshots/private website preview; the review archive includes the revised corresponding source package and GPL attribution/licensing.
3. **Do not publish** until the user explicitly approves this exact revision. If source or live baseline changes, rebase and seek fresh approval. The standalone `Website-Files` directory is only a ZIP preview candidate, **not** a live push or deployment.
4. No GitHub branch was created or modified, no commit was pushed, and no site deployment was triggered.

**Draft ready — awaiting approval.**
