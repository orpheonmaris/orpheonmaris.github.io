# R28 private review — E1-R28-3679a7a6923b

**Draft ready — awaiting approval. Not published.**

Compared with **live U1.98 / native 106 / E1-R27-a258487bfd85**, source commit `c1662cd5e0d915388d716b2a5634204ee2b67d78`. Candidate: **U1.99**. The R27 publication receipt and source archive SHA256 match; R27 was published. No site workflow was invoked in this round.

## Batch and scope

Review adjacent outcomes at `q_universalPPW` after a complete ten-outcome subtree audit in R27 found two still-failing ancestors. This round does not mask those problems: `q_nepTime` (coercive collectivization) and `q_classStruggleSocialism` (ambiguous class-struggle stage) remain **failed and unchanged**.

Primary scope: two neighboring terminal descriptions, one misleading generic alias, and candidate version markers. No question, answer, edge, result name, family, image, icon, CSS or layout is altered. Both complete routes remain 14 answers.

## Exact before and after

### Maoism

**Before:**

> War can only be abolished through war, and in order to get rid of the gun it is necessary to take up the gun.

Attribution: `Mao Zedong`.

**After:**

> José María Sison’s Philippine Maoism advances protracted people’s war in semicolonial, semifeudal conditions. He regards continuing revolution under proletarian dictatorship as Mao’s key contribution. Unlike the Peruvian ‘principally Maoism’ current, he rejects people’s war as a universal strategy.

Attribution: `Editorial description`.

Source: [Sison interview on Maoism (2019–2020)](https://www.researchgate.net/publication/340377842_Questions_on_Mao_Zedong_ThoughtMaoism).

Source details: Regletto Aldrich Imbong and José María Sison, “Questions on Mao Zedong Thought/Maoism,” November 18, 2019–February 25, 2020, answers to questions 1–2.

Scope note: A dated Sison/Philippine profile, not a general definition of every movement called Maoist or Marxist-Leninist-Maoist; editorial paraphrase, not a direct quotation.

**Root route:** No (`q_privateProperty`) → No (`q_markets`) → Yes (`q_communism`) → Yes (`q_dotp`) → No (`q_foco`) → Yes (`q_stalinCope`) → No (`q_pluralistAlliance`) → No (`q_socialistMarkets`) → Yes (`q_nepTime`) → Yes (`q_classStruggleSocialism`) → No (`q_chinaBourgeois`) → No (`q_laborAristocracy`) → Yes (`q_peopleWar`) → No (`q_universalPPW`)

### Marxism-Leninism-Maoism, principally Maoism

**Before:**

> Fear? I believe that fear and lack of fear form a contradiction. The point is to take up our ideology, and unleash the courage within us. It is our ideology that makes us brave, that gives us courage. In my opinion, no one is born brave. It is society, the class struggle, that makes people and communists courageous--the class struggle, the proletariat, the Party, and our ideology.

Attribution: `Abimael Guzmán`.

**After:**

> The Communist Party of Peru’s 1988 line treats protracted people’s war as applicable in every country, adapted to local conditions. It centers Gonzalo Thought and a militarized party. Its universal claim separates it from Sison’s Philippine Maoism.

Attribution: `Editorial description`.

Source: [Communist Party of Peru, Military Line (1988)](https://redlibrary.info/works/pcp/military-line).

Source details: Communist Party of Peru, “General Political Line: III. Military Line” (1988), Introduction and I.1; also “Program and Statutes” (1988), Program, principles.

Scope note: Identifies the PCP/Gonzalo Thought current at the 1988 programme, not all Marxist-Leninist-Maoists; editorial paraphrase, not a direct quotation.

**Root route:** No (`q_privateProperty`) → No (`q_markets`) → Yes (`q_communism`) → Yes (`q_dotp`) → No (`q_foco`) → Yes (`q_stalinCope`) → No (`q_pluralistAlliance`) → No (`q_socialistMarkets`) → Yes (`q_nepTime`) → Yes (`q_classStruggleSocialism`) → No (`q_chinaBourgeois`) → No (`q_laborAristocracy`) → Yes (`q_peopleWar`) → Yes (`q_universalPPW`)

### Exact alias change (Maoism)

*Removed:* `Marxism-Leninism-Maoism` (generic—also claimed by the neighboring Peruvian current).
*Added:* `Maoism (Sison)`.
*Retained:* `Marxism-Leninism-Maoism (Sison)` and `Sison-style MLM`.

## Genuine fork and hard-case tests

**`q_universalPPW`: “Is protracted people’s war universally applicable?”**

**Yes commitment:** The PCP 1988 military line applies people’s war to all types of countries, adjusted to their conditions.

**No commitment:** Sison upholds people’s war under Philippine conditions but rejects universal applicability. No does **not** mean rejecting the revolutionary strategy in the Philippines or rejecting Maoism.

Sources: Communist Party of Peru, [*Military Line*, I.1 (1988)](https://redlibrary.info/works/pcp/military-line); PCP, [*Program and Statutes* (1988)](https://redlibrary.info/works/pcp/program-and-statutes); Imbong and Sison, [*Questions on Mao Zedong Thought/Maoism* (2019–2020)](https://www.researchgate.net/publication/340377842_Questions_on_Mao_Zedong_ThoughtMaoism). These are statements of advocacy; the archive notes translation and historical context.

Both profiles answer Yes at `q_peopleWar`. The No-side of that parent contains other currents and has not received independent revalidation. For both 14-answer routes, the generated path demonstrates reachability—not that their nine preceding ancestor answers are factually endorsed by the featured thinkers.

## Source and UI checks

- **182** questions, **382** answer edges, **201** distinct results, **201** unique terminating routes. Tree generator covers both branches without gaps or duplicate endpoints. **0** changed routes.
- **15 of 15 executable source-level tests passed**, including new R28 scoped-description and alias regression.
- Chromium offline QA replayed both 14-answer paths and result cards on **1440×900** and **390×844**, without horizontal page overflow. Verified result source details, 14-item route disclosures, Back, Retake, `Showing 1 outcome` search, both Tree branches, About disclaimer, and visible GPL link.
- The browser sandbox prohibits all external/local navigation; desktop and mobile results were checked by inlining unchanged app HTML, CSS and JavaScript and supplying the authored JSON through a memory fixture. **Image URLs were unavailable in that fixture**. Do not interpret screenshots as production artwork tests.
- **Official build/worker-render test not completed:** installation of dependency artifacts failed. The earlier published R27 had a verified official build; this does not certify the R28 bundle. That check is required before production publication.
- The static core grows by **1107 bytes** (from 310656 to 311763). The static byte test ceiling is explicitly adjusted from 310,850 to 312,000 for this source-backed description expansion; all source-level tests pass.

## Edition progress

| Measure | Reviewed / total |
|:--|--:|
| Result-card claims | **40 / 201** |
| Locally verified forks | **13 / 182** |
| Scoped answer commitments | **26 / 382** |
| Complete independent evidence profiles | **2 / 201** |
| Coverage issues resolved | **0 / 6** |
| Deterministic routes/connectivity | **201 / 201** |

**Next:** Return to the two failed upstream gateway forks, research the Romanian 1964 and generic ML edge cases, and preserve all earlier explicit wording decisions. Their failure is documented in R27 and remains unresolved.

**Publication rule:** Only an explicit “Publish this draft” in response to this **exact** R28 candidate, with an unchanged U1.98 baseline, would authorize deployment. A changed candidate or baseline needs a new review and approval.
