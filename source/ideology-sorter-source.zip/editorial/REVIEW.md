# Ideology Sorter — Edition 1 / Round 29

**Draft E1-R29-9d0af24a9432 — awaiting explicit approval.**

**Live baseline:** R28 / U1.99, GitHub `main` `1fb0e1255210bc8400fe7b4a34b64c0ea929d2ba`. **Candidate:** U1.100. No production changes or deployment.

## Summary

Three historically scoped Soviet result-card descriptions and their source notes change. All 182 questions, 382 answer destinations, 201 outcomes and 201 complete routes remain identical. The inherited agrarian and class-struggle gateways still fail exclusivity; R29 does not claim them fixed.

## Exact before-and-after text

### Developed Socialism (Brezhnev)

**Before:**

> Brezhnev-era developed socialism treated mature socialism as a prolonged stage on the road to communism. It retained public ownership, economic planning and Communist Party leadership. In party organization, it replaced Khrushchev’s mandatory turnover quotas with selection based on officials’ qualifications and local conditions. The rules still called for leadership renewal and continuity, but no longer required a minimum share of new members at each election.

**After (draft):**

> Brezhnev-era developed socialism treated mature Soviet socialism as a prolonged stage on the road to communism. The 1977 constitution described the USSR as a “socialist state of the whole people” in which class antagonisms had been overcome; it did not claim that all socialist societies had reached that stage. The programme retained public ownership, planning and Communist Party leadership. After the 1966 revision, party rules encouraged leadership renewal but no longer required minimum turnover quotas, distinguishing this period from Khrushchev’s 1961 programme.

**Attribution:** Editorial description → Editorial description. **Source:** USSR Constitution (1977); Soviet party rules after 1966.

**Citation:** Constitution (Fundamental Law) of the USSR, adopted October 7, 1977, preamble and arts. 1, 6, 10, 16; Leonid Brezhnev, On the Draft Constitution of the USSR, October 4, 1977, pp. 23–26; I. Pronin and M. Stepichev, Leninist Standards of Party Life (Moscow: Progress, 1969), pp. 70–71, on the 23rd Party Congress and renewal percentages.

**Root route:** No → No → Yes → Yes → No → Yes → No → No → Yes → No → No (11 answers); route unchanged.

### Marxism-Leninism

**Before:**

> Internationalism grows where national culture flourishes. To forget this is to lose one's individuality and become a cosmopolitan without a country.

**After (draft):**

> Stalin-era Marxism-Leninism presents Leninism as Marxist theory and revolutionary strategy for the age of imperialism. It centers a vanguard communist party and the dictatorship of the proletariat, and holds that socialism can be built in one country despite continued capitalist encirclement. Its late-1920s Soviet strategy favored accelerated industrialization and expanded collective and state farms over Bukharin’s prolonged NEP approach. This period-specific profile does not define every movement calling itself Marxist-Leninist.

**Attribution:** Andrei Aleksandrovich Zhdanov → Editorial description. **Source:** Stalin: Leninism and Soviet economic strategy (1924–1929).

**Citation:** J. V. Stalin, The Foundations of Leninism (1924; Works, vol. 6, chs. IV, VIII); Concerning Questions of Leninism (1926), §VI on socialism in one country; The Right Deviation in the C.P.S.U.(B.), April 1929, §IV(d), (f), (h)–(j) on NEP, agricultural collectivization and industrialization.

**Root route:** No → No → Yes → Yes → No → Yes → No → No → Yes → Yes → No → No → No → No (14 answers); route unchanged.

### Marxism-Leninism (Khrushchev)

**Before:**

> Khrushchev’s 1961 Soviet program combined public ownership and economic planning with a drive to build communism in its main features by 1980. It retained commodity exchange during socialist development, with its eventual disappearance under communism. To curb entrenched leadership, it required minimum shares of party committees to be renewed at each election. These quotas distinguish this program from the Brezhnev-era approach.

**After (draft):**

> The 1961 CPSU programme declared that proletarian dictatorship had fulfilled its domestic task in the USSR and that the Soviet state had become a “state of the entire people.” This claim concerned a particular Soviet stage, not a denial of earlier class struggle during socialist construction. It combined planning, public ownership and transitional commodity exchange with a goal of building communism in its main features by 1980. Its party rules required minimum shares of leadership bodies to be renewed at each election, unlike the later Brezhnev rules.

**Attribution:** Editorial description → Editorial description. **Source:** CPSU: 1961 Programme and Rules.

**Citation:** Programme of the Communist Party of the Soviet Union, adopted October 31, 1961 (Moscow: Foreign Languages Publishing House, 1961), pp. 59–62, 79–83, 91–92 (state of the entire people); Rules of the CPSU, adopted October 31, 1961, art. 25 (minimum renewal percentages).

**Root route:** No → No → Yes → Yes → No → Yes → No → No → Yes → No → Yes (11 answers); route unchanged.

## Unresolved routing — not hidden by these edits

**`q_nepTime`:** “Was the Soviet Union under Stalin right to forcefully collectivize agriculture?” Yes routes to nine different Marxist-Leninist and adjacent currents; No routes to Bukharinism. Stalin publicly repudiated compelled farm membership while favoring collectivization; Bukharin also favored voluntary cooperative agriculture. The fork remains **failed and unchanged**.

**`q_classStruggleSocialism`:** “Does class struggle persist within the socialist mode of production?” Khrushchev’s 1961 programme acknowledges class struggle during socialist construction while declaring the dictatorship of the proletariat no longer necessary at the purported later Soviet stage; Brezhnev’s 1977 constitution endorses the state of the whole people. The unqualified Yes/No remains **failed and unchanged**.

The valid local R26 `q_khrushBrezhnev` minimum-renewal-share split is not changed. Neither source quotations nor later proposed wording changes were treated as user-approved revisions.

## Validation and limitations

The automated graph suite verifies 182 reachable questions, 382 answers, 201 unique terminating results, 0 missing destinations, 0 cycles, and identical routes. Sixteen source-level Node tests pass; no official Next/Vite production build was performed. Browser QA used actual HTML, CSS, JS and both JSON files in an in-memory Chromium document because localhost navigation is blocked. Desktop 1440×900 and mobile 390×844 replays passed for each applicable test, with source details, About, Tree, Retake and one-result search; asset URLs could not be verified in this offline fixture.

## Historical evidence

- **R29-S01** J. V. Stalin, The Foundations of Leninism (1924), chapters IV and VIII — https://www.marxists.org/reference/archive/stalin/works/1924/foundations-leninism/index.htm
- **R29-S02** J. V. Stalin, Concerning Questions of Leninism (1926), chapter VI — https://www.marxists.org/reference/archive/stalin/works/1926/01/25.htm
- **R29-S03** J. V. Stalin, The Right Deviation in the C.P.S.U.(B.), April 1929, section IV(d), (f), (h)–(j), Works vol. 12 — https://marx2mao.redspark.nu/Stalin/TRD29.html
- **R29-S04** J. V. Stalin, Dizzy with Success, Pravda March 2, 1930, Works vol. 12 pp. 197–205 — https://www.marxists.org/reference/archive/stalin/works/1930/03/02.htm
- **R29-S05** A. A. Zhdanov, address on Soviet music, 1948; collected in On Literature, Music and Philosophy — https://www.revolutionarydemocracy.org/archive/zhdanovlit.htm
- **R29-S06** CPSU Programme, 22nd Congress October 31, 1961, FLPH 1961, printed pp. 91–92 — https://www.bannedthought.net/USSR/CPSU-CapitalistEra/ProgrammeOfTheCPSU-1961-Marked-OCR.pdf
- **R29-S07** CPSU Rules of 1961, art. 25 — https://www.marxists.org/history/ussr/cpsu/cpsu-rules/rulescpsu1961.pdf
- **R29-S08** 1977 USSR Constitution, preamble and arts. 1, 6, 10, 16 — https://www.servat.unibe.ch/icl/r100000_.html
- **R29-S09** I. Pronin and M. Stepichev, Leninist Standards of Party Life, Progress, 1969, printed pp. 70–71; R26 source dossier — https://www.marxists.org/history/ussr/cpsu/1969/leninist-standards-of-party-life.pdf
- **R29-S10** Nikolai Bukharin, Notes of an Economist, Pravda September 30, 1928, English Inprecorr 8 nos.73,77 — https://revolutionsnewsstand.com/2023/04/14/observations-o-an-economist-the-beginning-of-the-new-economic-year-by-nikolai-bukharin-from-international-press-correspondence-vol-8-nos-73-77-october-19-november-2/
- **R29-S11** Romanian Workers’ Party, April 22, 1964 Declaration (Fordham extract) — https://sourcebooks.fordham.edu/mod/1964romania-china.asp
- **R29-S12** CPC editorial departments, On Khrushchov’s Phoney Communism (1964), section Refutation of the So-Called State of the Whole People — https://www.marxists.org/reference/archive/mao/works/1964/phnycom.htm

## Release rule

**This R29 draft has not been published.** Do not edit GitHub `main` or update the custom-domain live site without explicit approval of this exact revision against the unchanged commit `1fb0e1255210bc8400fe7b4a34b64c0ea929d2ba`. If baseline moves, obtain new approval after re-diffing.

