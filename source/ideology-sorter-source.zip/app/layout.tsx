import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://ideology-sorter.com"),
  title: "Ideology Sorter",
  description: "Explore 201 political ideologies through one complete decision tree.",
  openGraph: {
    title: "Ideology Sorter",
    description: "201 ideologies. 183 questions. One complete decision tree.",
    url: "https://ideology-sorter.com",
    siteName: "Ideology Sorter",
    type: "website",
    images: [
      {
        url: "https://ideology-sorter.com/og.png?v=school-of-athens-20260909",
        width: 1200,
        height: 630,
        alt: "Ideology Sorter over Raphael’s The School of Athens",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Ideology Sorter",
    description: "201 ideologies. One decision tree.",
    images: [
      {
        url: "https://ideology-sorter.com/og.png?v=school-of-athens-20260909",
        alt: "Ideology Sorter over Raphael’s The School of Athens",
      },
    ],
  },
  icons: {
    icon: "/assets/quark/logos/icon.png",
    shortcut: "/assets/quark/logos/icon.png",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#292a29",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
