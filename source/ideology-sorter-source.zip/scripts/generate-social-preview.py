"""Typeset the site title over the public-domain painting. Requires Pillow."""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
SIZE = (1200, 630)
FONT_PATH = ROOT / "public/assets/quark/fonts/heavitas.ttf"

with Image.open(ROOT / "artwork/school-of-athens.jpg") as original:
    cover = ImageOps.fit(original.convert("RGB"), SIZE, Image.Resampling.LANCZOS).convert("RGBA")

# The title sits in the architecture above the figures.
shade = Image.new("RGBA", SIZE)
shade_draw = ImageDraw.Draw(shade)
for y in range(SIZE[1]):
    opacity = round(118 - 68 * min(1, y / 470))
    shade_draw.line((0, y, SIZE[0], y), fill=(9, 11, 15, opacity))
cover = Image.alpha_composite(cover, shade)

font = ImageFont.truetype(str(FONT_PATH), 116)
lettering = Image.new("RGBA", SIZE)
text = ImageDraw.Draw(lettering)
for label, top in [("IDEOLOGY", 100), ("SORTER", 220)]:
    bounds = font.getbbox(label)
    x = round((SIZE[0] - (bounds[2] - bounds[0])) / 2) - bounds[0]
    text.text((x, top - bounds[1]), label, font=font, fill="white")

shadow = Image.new("RGBA", SIZE, (0, 0, 0, 0))
shadow.putalpha(lettering.getchannel("A").filter(ImageFilter.GaussianBlur(9)).point(lambda a: round(a * 0.75)))
cover = Image.alpha_composite(cover, shadow)
cover = Image.alpha_composite(cover, lettering).convert("RGB")
cover.save(ROOT / "public/og.png", optimize=True)
print("Created public/og.png: 1200 × 630, source painting and title only.")
