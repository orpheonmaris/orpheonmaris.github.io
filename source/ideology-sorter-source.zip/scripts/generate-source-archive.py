"""Refresh the corresponding source download from tracked and new project files."""

from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "public/source/ideology-sorter-source.zip"

paths = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
    cwd=ROOT,
).decode().split("\0")

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for relative in sorted(set(paths)):
        if not relative:
            continue
        source = ROOT / relative
        if source == OUTPUT or not source.is_file():
            continue
        archive.write(source, relative)

with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.read("app/quiz-data.json") == (ROOT / "app/quiz-data.json").read_bytes()
    assert archive.read("app/tree-layout.json") == (ROOT / "app/tree-layout.json").read_bytes()
    print(f"Updated corresponding source archive: {len(archive.namelist())} files")
