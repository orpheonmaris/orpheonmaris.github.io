"""Apply only the communist-integration proposal approved in the chat."""
import copy
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE_COMMIT = 'a53b9a9ae1a3811a1c7ba4e5713c828c4d5f159b'
before = json.loads(subprocess.check_output(['git','show',BASE_COMMIT+':app/quiz-data.json'],cwd=ROOT))
after = copy.deepcopy(before)
g = after['graph']
def q(i): return {'type':'question','id':i}
def r(n): return {'type':'result','ideology':n}
def dest(i, label, target):
    choices = g[i]['choices']
    j = next(j for j,c in enumerate(choices) if c['label'] == label)
    choices[j] = {'label':label, **target}
def binary(i, text, yes, no, explanation=None):
    g[i] = {'question':text, 'choices':[{'label':'Yes',**yes},{'label':'No',**no}]}
    if explanation: g[i]['explanation'] = explanation

dest('q_dotp','Yes',q('q_foco'))
dest('q_stalinCope','Yes',q('q_pluralistAlliance'))
dest('q_stalinCope','No',q('q_reform'))
dest('q_reform','Yes',q('q_massparty'))
dest('q_reform','No',q('q_demCent'))
binary('q_pluralistAlliance','Should socialism preserve a pluralist parliamentary system?',r('Eurocommunism'),q('q_socialistMarkets'),
       'Rival parties remain free to compete for government under socialism. This is different from allowing an election to begin the transition.')
binary('q_socialistMarkets','Should market exchange be the main regulator of socialist production?',q('q_enterprisePlans'),q('q_nepTime'),
       'This asks whether markets should chiefly regulate production during socialism, not whether all trade disappears immediately or markets last into full communism.')
binary('q_enterprisePlans','Should production plans in large enterprises require approval by elected workers’ councils?',r('Titoism'),r('Marxism-Leninism-MZT'),
       'The question concerns binding approval of production plans. Consultation, elected managers, or approval of wages and welfare are different powers.')
dest('q_peopleWar','Yes',q('q_universalPPW'))
dest('q_guilds','Through market competition',r('Market socialism'))
del g['q_marketPolitical']
del g['q_muhCapitalistRoaders']

changes=[{'id':i,'before':before['graph'].get(i),'after':g.get(i)} for i in sorted(set(before['graph'])|set(g)) if before['graph'].get(i)!=g.get(i)]
digest=hashlib.sha256(json.dumps(changes,sort_keys=True).encode()).hexdigest()[:12]
assert digest=='af832a063f8c', 'Restored proposal differs from the reviewed graph changes'
after['version']='U1.92'
(ROOT/'app/quiz-data.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
for name in ['public/index.html','public/ideosorter.js','app/page.tsx']:
    p=ROOT/name
    p.write_text(p.read_text().replace('U1.88','U1.92'))
(ROOT/'editorial/approved-communist-routing-R21.json').write_text(json.dumps({
    'proposal_id':'communist-integration-'+digest,
    'baseline_commit':BASE_COMMIT,'baseline_site_version':'U1.88','baseline_native_version':99,
    'site_version':'U1.92','approval':'Make all of the changes in the live sitre',
    'approved_question_changes':changes,
    'scope':'Only the reviewed communist integration and matching Tree connections; rejected R20 redesign excluded.',
    'qualifications':['Lange and the broader market gateway remain outside this approved repair.',
    'The retired Tito/Schweickart fork no longer independently tests constitutional pluralism on the Schweickart route. Its description remains unchanged.',
    'Connectivity tests do not certify every historical profile or the entire editorial edition.']
},ensure_ascii=False,indent=2)+'\n')
print('Recovered approved proposal:',digest,'question records:',len(changes))
