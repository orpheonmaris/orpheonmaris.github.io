# Ideology Sorter project instructions

## Option icons

- Reuse an existing icon only when the option is of the same general nature as the icon's established meaning and is actually represented by its visible symbol.
- Inspect the SVG itself before reusing it. A filename or a shared word in the answer is not enough: a megaphone does not represent autonomous communes, for example.
- If there is no genuine semantic match, create a dedicated SVG in the site's existing pictogram style: solid white, bold simple geometry, transparent background, square canvas, and legibility at small button sizes. Avoid fine detail, gradients, emoji, and text.
- Map custom wording explicitly by question and answer in both `public/ideosorter.js` and `app/page.tsx`. Never guess icons from broad keyword or answer-position fallbacks.
- Keep questions, routes, button colors, and layout unchanged for icon-only requests. Validate that every current answer has a real icon and that both renderers agree.
